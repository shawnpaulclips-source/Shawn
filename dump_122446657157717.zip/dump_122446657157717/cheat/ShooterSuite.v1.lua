--// ShooterSuite: client-side ESP, FOV wheel, silent aim, wallbang, menu
--// Built against the dumped entity layout:
--//   Workspace.World.<room>.Entities.<model>   attrs: Team, Health, MaxHealth, Role
--//     .Collider  (Model) -> Head, Body, Arm, Leg
--//     .HumanoidRootPart
--// Team check reads the LocalPlayer "Team" attribute.

local env = (getgenv and getgenv()) or _G
if env.__SHOOTER_SUITE_UNLOAD then
	pcall(env.__SHOOTER_SUITE_UNLOAD)
end

assert(Drawing, "Drawing library not available on this executor")
assert(hookmetamethod and getnamecallmethod and newcclosure and checkcaller, "Executor is missing metamethod hooks")

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UIS = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local CoreGui = game:GetService("CoreGui")
local Workspace = game:GetService("Workspace")

local LocalPlayer = Players.LocalPlayer
local ProtectedRoot = (gethui and gethui()) or CoreGui

local Unloaded = false
local Connections = {}
local Refreshers = {}
local Capture = nil
local LockedTarget = nil
local unload

local Accents = {
	{ Name = "Ember", Color = Color3.fromRGB(255, 92, 58) },
	{ Name = "Acid", Color = Color3.fromRGB(176, 255, 84) },
	{ Name = "Violet", Color = Color3.fromRGB(150, 112, 255) },
	{ Name = "Glacier", Color = Color3.fromRGB(96, 214, 255) },
}

local Config = {
	TeamCheck = true,
	ESP = {
		Enabled = true,
		Box = true,
		Skeleton = true,
		Healthbar = true,
		Name = true,
		Distance = true,
		Tracer = true,
		Chams = false,
		MaxDistance = 2500,
		EnemyColor = Color3.fromRGB(255, 92, 58),
		TeamColor = Color3.fromRGB(96, 214, 255),
	},
	Aim = {
		SilentAim = false,
		Wallbang = false,
		FireCheck = true,
		VisibleOnly = true,
		FOVRadius = 150,
		ShowFOV = true,
		Pulse = true,
		Ticks = true,
		CenterDot = true,
		Line = true,
		Travel = true,
	},
	Menu = {
		Key = Enum.KeyCode.Insert,
		Accent = 1,
	},
}

local function accentColor()
	return Accents[Config.Menu.Accent].Color
end

local function clamp(v, lo, hi)
	return math.max(lo, math.min(hi, v))
end

local function bind(signal, fn)
	local c = signal:Connect(fn)
	table.insert(Connections, c)
	return c
end

local function newDraw(class, props)
	local d = Drawing.new(class)
	for k, v in pairs(props or {}) do
		d[k] = v
	end
	d.Visible = false
	return d
end

local HighlightFolder = Instance.new("Folder")
HighlightFolder.Name = "ShooterSuiteHL"
HighlightFolder.Parent = ProtectedRoot

local Entities = {}

local function makeStore(model)
	local store = {
		Box = newDraw("Square", { Thickness = 1.3, Filled = false, Color = Color3.new(1, 1, 1) }),
		BoxOut = newDraw("Square", { Thickness = 3, Filled = false, Color = Color3.new(0, 0, 0) }),
		HPBack = newDraw("Square", { Filled = true, Color = Color3.fromRGB(10, 10, 12) }),
		HPFill = newDraw("Square", { Filled = true, Color = Color3.fromRGB(110, 230, 140) }),
		Label = newDraw("Text", { Size = 13, Center = true, Outline = true, Font = 2, Color = Color3.new(1, 1, 1) }),
		Tracer = newDraw("Line", { Thickness = 1.2, Color = Color3.new(1, 1, 1) }),
		Bones = {},
		Highlight = Instance.new("Highlight"),
	}
	for i = 1, 8 do
		store.Bones[i] = newDraw("Line", { Thickness = 1.2, Color = Color3.new(1, 1, 1) })
	end
	local hl = store.Highlight
	hl.Adornee = model
	hl.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
	hl.FillTransparency = 0.6
	hl.OutlineTransparency = 0
	hl.Enabled = false
	hl.Parent = HighlightFolder
	return store
end

local function hideStore(store)
	store.Box.Visible = false
	store.BoxOut.Visible = false
	store.HPBack.Visible = false
	store.HPFill.Visible = false
	store.Label.Visible = false
	store.Tracer.Visible = false
	for _, b in ipairs(store.Bones) do
		b.Visible = false
	end
	store.Highlight.Enabled = false
end

local function destroyStore(store)
	store.Box:Remove()
	store.BoxOut:Remove()
	store.HPBack:Remove()
	store.HPFill:Remove()
	store.Label:Remove()
	store.Tracer:Remove()
	for _, b in ipairs(store.Bones) do
		b:Remove()
	end
	store.Highlight:Destroy()
end

local function scanEntities()
	local seen = {}
	local world = Workspace:FindFirstChild("World")
	if world then
		for _, room in ipairs(world:GetChildren()) do
			local folder = room:FindFirstChild("Entities")
			if folder then
				for _, model in ipairs(folder:GetChildren()) do
					if model:IsA("Model") then
						seen[model] = true
						if not Entities[model] then
							Entities[model] = makeStore(model)
						end
					end
				end
			end
		end
	end
	for model, store in pairs(Entities) do
		if not seen[model] or not model.Parent then
			destroyStore(store)
			Entities[model] = nil
		end
	end
end

local function getParts(model)
	local collider = model:FindFirstChild("Collider")
	if not collider or not collider:IsA("Model") then
		return nil
	end
	local head = collider:FindFirstChild("Head")
	local root = model:FindFirstChild("HumanoidRootPart") or collider:FindFirstChild("HumanoidRootPart")
	if not (head and root) then
		return nil
	end
	local parts = {
		Collider = collider,
		Head = head,
		Root = root,
		Body = collider:FindFirstChild("Body"),
		Legs = {},
		Arms = {},
	}
	for _, child in ipairs(collider:GetChildren()) do
		if child:IsA("BasePart") then
			if child.Name == "Leg" then
				table.insert(parts.Legs, child)
			elseif child.Name == "Arm" then
				table.insert(parts.Arms, child)
			end
		end
	end
	return parts
end

local function entityInfo(model)
	local hp = model:GetAttribute("Health") or 0
	local maxhp = model:GetAttribute("MaxHealth") or math.max(hp, 1)
	local team = model:GetAttribute("Team")
	return hp, maxhp, team
end

local function isSelf(model, parts)
	if model == LocalPlayer.Character then
		return true
	end
	if model:GetAttribute("UserId") == LocalPlayer.UserId then
		return true
	end
	local cam = Workspace.CurrentCamera
	return cam ~= nil and (parts.Head.Position - cam.CFrame.Position).Magnitude < 1.5
end

local function isEnemy(team)
	if not Config.TeamCheck then
		return true
	end
	local localTeam = LocalPlayer:GetAttribute("Team")
	return team == nil or localTeam == nil or team ~= localTeam
end

local function screenPoint(pos)
	local cam = Workspace.CurrentCamera
	local v = cam:WorldToViewportPoint(pos)
	return Vector2.new(v.X, v.Y), v.Z > 0
end

local function boxBounds(collider)
	local cam = Workspace.CurrentCamera
	local cf, size = collider:GetBoundingBox()
	local minX, minY, maxX, maxY = math.huge, math.huge, -math.huge, -math.huge
	local front = false
	for _, sx in ipairs({ -1, 1 }) do
		for _, sy in ipairs({ -1, 1 }) do
			for _, sz in ipairs({ -1, 1 }) do
				local v = cam:WorldToViewportPoint(cf * Vector3.new(sx * size.X / 2, sy * size.Y / 2, sz * size.Z / 2))
				if v.Z > 0 then
					front = true
					minX = math.min(minX, v.X)
					maxX = math.max(maxX, v.X)
					minY = math.min(minY, v.Y)
					maxY = math.max(maxY, v.Y)
				end
			end
		end
	end
	if not front then
		return nil
	end
	return minX, minY, maxX, maxY
end

local visParams = RaycastParams.new()
visParams.FilterType = Enum.RaycastFilterType.Exclude
visParams.IgnoreWater = true

local function isVisible(part, model)
	local cam = Workspace.CurrentCamera
	local origin = cam.CFrame.Position
	local ignore = { model, cam }
	if LocalPlayer.Character then
		table.insert(ignore, LocalPlayer.Character)
	end
	visParams.FilterDescendantsInstances = ignore
	local hit = Workspace:Raycast(origin, part.Position - origin, visParams)
	return hit == nil
end

local function findTarget()
	local aim = Config.Aim
	local cam = Workspace.CurrentCamera
	local center = Vector2.new(cam.ViewportSize.X / 2, cam.ViewportSize.Y / 2)
	local best, bestDist = nil, math.huge
	for model in pairs(Entities) do
		local parts = getParts(model)
		if parts then
			local hp, _, team = entityInfo(model)
			if hp > 0 and not isSelf(model, parts) and isEnemy(team) then
				local sp, front = screenPoint(parts.Head.Position)
				if front then
					local d = (sp - center).Magnitude
					if d <= aim.FOVRadius and d < bestDist then
						if aim.Wallbang or not aim.VisibleOnly or isVisible(parts.Head, model) then
							bestDist = d
							best = { Model = model, Head = parts.Head, Screen = sp }
						end
					end
				end
			end
		end
	end
	return best
end

local Overlay = {
	Ring = newDraw("Circle", { Thickness = 1.5, NumSides = 96, Filled = false }),
	Ticks = {},
	Dot = newDraw("Circle", { Filled = true, NumSides = 24 }),
	HeadRing = newDraw("Circle", { Thickness = 1.4, NumSides = 24, Filled = false }),
	Line = newDraw("Line", { Thickness = 1.5 }),
	Travel = newDraw("Line", { Thickness = 3, Color = Color3.new(1, 1, 1) }),
}
for i = 1, 4 do
	Overlay.Ticks[i] = newDraw("Line", { Thickness = 1.5 })
end

local function updateOverlay(t, target)
	local aim = Config.Aim
	local cam = Workspace.CurrentCamera
	local center = Vector2.new(cam.ViewportSize.X / 2, cam.ViewportSize.Y / 2)
	local accent = accentColor()
	local pulse = (math.sin(t * 3.2) + 1) / 2
	local radius = aim.FOVRadius + (aim.Pulse and pulse * 6 or 0)

	Overlay.Ring.Visible = aim.ShowFOV
	Overlay.Ring.Position = center
	Overlay.Ring.Radius = radius
	Overlay.Ring.Color = accent
	Overlay.Ring.Transparency = aim.Pulse and (0.35 + 0.65 * pulse) or 0.8

	for i, tick in ipairs(Overlay.Ticks) do
		local ang = t * 1.1 + (i - 1) * math.pi / 2
		local dir = Vector2.new(math.cos(ang), math.sin(ang))
		tick.Visible = aim.ShowFOV and aim.Ticks
		tick.From = center + dir * (radius - 9)
		tick.To = center + dir * (radius - 2)
		tick.Color = accent
	end

	if target then
		local hp = target.Screen
		Overlay.Dot.Visible = aim.CenterDot
		Overlay.Dot.Position = center
		Overlay.Dot.Radius = 2.5 + pulse * 2
		Overlay.Dot.Color = accent

		Overlay.Line.Visible = aim.Line
		Overlay.Line.From = center
		Overlay.Line.To = hp
		Overlay.Line.Color = accent
		Overlay.Line.Transparency = 0.6 + 0.4 * pulse

		Overlay.HeadRing.Visible = true
		Overlay.HeadRing.Position = hp
		Overlay.HeadRing.Radius = 5 + pulse * 3
		Overlay.HeadRing.Color = accent

		local f = (t * 0.9) % 1
		Overlay.Travel.Visible = aim.Line and aim.Travel
		Overlay.Travel.From = center:Lerp(hp, f)
		Overlay.Travel.To = center:Lerp(hp, math.min(f + 0.12, 1))
	else
		Overlay.Dot.Visible = false
		Overlay.Line.Visible = false
		Overlay.HeadRing.Visible = false
		Overlay.Travel.Visible = false
	end
end

local function updateESP(store, model, parts, hp, maxhp, friendly)
	local esp = Config.ESP
	local cam = Workspace.CurrentCamera
	local dist = (parts.Root.Position - cam.CFrame.Position).Magnitude
	if dist > esp.MaxDistance then
		hideStore(store)
		return
	end

	local color = friendly and esp.TeamColor or esp.EnemyColor
	local x1, y1, x2, y2 = boxBounds(parts.Collider)
	if not x1 then
		hideStore(store)
		return
	end
	local w, h = x2 - x1, y2 - y1

	store.Box.Visible = esp.Box
	store.Box.Position = Vector2.new(x1, y1)
	store.Box.Size = Vector2.new(w, h)
	store.Box.Color = color
	store.BoxOut.Visible = esp.Box
	store.BoxOut.Position = Vector2.new(x1, y1)
	store.BoxOut.Size = Vector2.new(w, h)

	local ratio = clamp(hp / math.max(maxhp, 1), 0, 1)
	store.HPBack.Visible = esp.Healthbar
	store.HPBack.Position = Vector2.new(x1 - 7, y1 - 1)
	store.HPBack.Size = Vector2.new(4, h + 2)
	store.HPFill.Visible = esp.Healthbar
	store.HPFill.Position = Vector2.new(x1 - 6, y2 - h * ratio)
	store.HPFill.Size = Vector2.new(2, h * ratio)
	store.HPFill.Color = Color3.new(1 - ratio, ratio, 0.25)

	local text = {}
	if esp.Name then
		table.insert(text, tostring(model:GetAttribute("Role") or model.Name))
	end
	if esp.Distance then
		table.insert(text, string.format("%dm", math.floor(dist)))
	end
	store.Label.Visible = #text > 0
	store.Label.Text = table.concat(text, "  ")
	store.Label.Position = Vector2.new((x1 + x2) / 2, y1 - 16)
	store.Label.Color = color

	local rootPos, rootOn = screenPoint(parts.Root.Position)
	store.Tracer.Visible = esp.Tracer and rootOn
	store.Tracer.From = Vector2.new(cam.ViewportSize.X / 2, cam.ViewportSize.Y)
	store.Tracer.To = rootPos
	store.Tracer.Color = color

	local body = parts.Body or parts.Root
	local segs = { { parts.Head, body } }
	for _, arm in ipairs(parts.Arms) do
		table.insert(segs, { body, arm })
	end
	for _, leg in ipairs(parts.Legs) do
		table.insert(segs, { body, leg })
	end
	for i, bone in ipairs(store.Bones) do
		local seg = segs[i]
		if seg and esp.Skeleton then
			local a, aOn = screenPoint(seg[1].Position)
			local b, bOn = screenPoint(seg[2].Position)
			bone.Visible = aOn and bOn
			bone.From = a
			bone.To = b
			bone.Color = color
		else
			bone.Visible = false
		end
	end

	store.Highlight.Enabled = esp.Chams
	store.Highlight.FillColor = color
	store.Highlight.OutlineColor = color
end

local function aimedVector(target, origin, magnitude)
	local delta = target.Head.Position - origin
	if delta.Magnitude < 0.01 then
		return nil
	end
	return delta.Unit * magnitude
end

local oldNamecall
oldNamecall = hookmetamethod(game, "__namecall", newcclosure(function(self, ...)
	if Unloaded or self ~= Workspace or checkcaller() then
		return oldNamecall(self, ...)
	end
	local aim = Config.Aim
	local target = LockedTarget
	if not target or not (aim.SilentAim or aim.Wallbang) or not target.Head.Parent then
		return oldNamecall(self, ...)
	end
	if aim.FireCheck and not UIS:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) then
		return oldNamecall(self, ...)
	end

	local method = getnamecallmethod()
	local args = table.pack(...)
	local camPos = Workspace.CurrentCamera.CFrame.Position

	if method == "Raycast" then
		local origin, direction = args[1], args[2]
		if typeof(origin) ~= "Vector3" or typeof(direction) ~= "Vector3" then
			return oldNamecall(self, ...)
		end
		if direction.Magnitude < 20 or (origin - camPos).Magnitude > 8 then
			return oldNamecall(self, ...)
		end
		local aimDir = aimedVector(target, origin, direction.Magnitude)
		if not aimDir then
			return oldNamecall(self, ...)
		end
		local params = args[3]
		if aim.Wallbang then
			params = RaycastParams.new()
			params.FilterType = Enum.RaycastFilterType.Include
			params.FilterDescendantsInstances = { target.Model }
			params.IgnoreWater = true
		end
		return oldNamecall(self, origin, aimDir, params)
	elseif method == "FindPartOnRay" or method == "FindPartOnRayWithIgnoreList" or method == "FindPartOnRayWithWhitelist" then
		local ray = args[1]
		if typeof(ray) ~= "Ray" then
			return oldNamecall(self, ...)
		end
		local origin, direction = ray.Origin, ray.Direction
		if direction.Magnitude < 20 or (origin - camPos).Magnitude > 8 then
			return oldNamecall(self, ...)
		end
		local aimDir = aimedVector(target, origin, direction.Magnitude)
		if not aimDir then
			return oldNamecall(self, ...)
		end
		local aimRay = Ray.new(origin, aimDir)
		if aim.Wallbang then
			return self.FindPartOnRayWithWhitelist(self, aimRay, { target.Model })
		end
		args[1] = aimRay
		return oldNamecall(self, table.unpack(args, 1, args.n))
	end

	return oldNamecall(self, ...)
end))

local lastScan = 0
local startClock = os.clock()

bind(RunService.RenderStepped, function()
	if Unloaded then
		return
	end
	local now = os.clock()
	if now - lastScan > 0.25 then
		lastScan = now
		scanEntities()
	end
	local t = now - startClock

	LockedTarget = findTarget()

	local esp = Config.ESP
	for model, store in pairs(Entities) do
		local parts = esp.Enabled and getParts(model) or nil
		if not parts then
			hideStore(store)
		else
			local hp, maxhp, team = entityInfo(model)
			local friendly = not isEnemy(team)
			if hp <= 0 or isSelf(model, parts) or (Config.TeamCheck and friendly) then
				hideStore(store)
			else
				updateESP(store, model, parts, hp, maxhp, friendly)
			end
		end
	end

	updateOverlay(t, LockedTarget)
end)

--// ───────────── Menu ─────────────

local Theme = {
	Window = Color3.fromRGB(15, 15, 19),
	Side = Color3.fromRGB(19, 19, 25),
	Row = Color3.fromRGB(24, 24, 31),
	RowHover = Color3.fromRGB(32, 32, 42),
	Stroke = Color3.fromRGB(44, 44, 56),
	Text = Color3.fromRGB(232, 232, 240),
	Dim = Color3.fromRGB(128, 128, 144),
	Off = Color3.fromRGB(52, 52, 66),
	Danger = Color3.fromRGB(235, 84, 98),
}

local function tween(obj, time, props, style)
	local tw = TweenService:Create(
		obj,
		TweenInfo.new(time, style or Enum.EasingStyle.Quint, Enum.EasingDirection.Out),
		props
	)
	tw:Play()
	return tw
end

local function corner(parent, radius)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0, radius)
	c.Parent = parent
	return c
end

local function stroke(parent, color, thickness)
	local s = Instance.new("UIStroke")
	s.Color = color
	s.Thickness = thickness or 1
	s.Parent = parent
	return s
end

local Gui = Instance.new("ScreenGui")
Gui.Name = "ShooterSuite"
Gui.ResetOnSpawn = false
Gui.IgnoreGuiInset = true
Gui.DisplayOrder = 999
Gui.Parent = ProtectedRoot

local Window = Instance.new("CanvasGroup")
Window.Name = "Window"
Window.Size = UDim2.fromOffset(600, 430)
Window.AnchorPoint = Vector2.new(0.5, 0.5)
Window.Position = UDim2.fromScale(0.5, 0.5)
Window.BackgroundColor3 = Theme.Window
Window.BorderSizePixel = 0
Window.Parent = Gui
corner(Window, 12)
stroke(Window, Theme.Stroke, 1)
local WindowScale = Instance.new("UIScale")
WindowScale.Parent = Window

local Title = Instance.new("Frame")
Title.Size = UDim2.new(1, 0, 0, 52)
Title.BackgroundColor3 = Theme.Side
Title.BorderSizePixel = 0
Title.Parent = Window
corner(Title, 12)

local TitleCover = Instance.new("Frame")
TitleCover.Size = UDim2.new(1, 0, 0, 14)
TitleCover.Position = UDim2.new(0, 0, 1, -14)
TitleCover.BackgroundColor3 = Theme.Side
TitleCover.BorderSizePixel = 0
TitleCover.Parent = Title

local AccentLine = Instance.new("Frame")
AccentLine.Size = UDim2.new(1, 0, 0, 2)
AccentLine.Position = UDim2.new(0, 0, 0, 52)
AccentLine.BackgroundColor3 = accentColor()
AccentLine.BorderSizePixel = 0
AccentLine.Parent = Window
local AccentGradient = Instance.new("UIGradient")
AccentGradient.Transparency = NumberSequence.new({
	NumberSequenceKeypoint.new(0, 0),
	NumberSequenceKeypoint.new(1, 1),
})
AccentGradient.Parent = AccentLine

local TitleLabel = Instance.new("TextLabel")
TitleLabel.BackgroundTransparency = 1
TitleLabel.Position = UDim2.fromOffset(18, 10)
TitleLabel.Size = UDim2.new(1, -90, 0, 22)
TitleLabel.Font = Enum.Font.GothamBlack
TitleLabel.TextSize = 16
TitleLabel.TextColor3 = Theme.Text
TitleLabel.TextXAlignment = Enum.TextXAlignment.Left
TitleLabel.Text = "SHOOTER SUITE"
TitleLabel.Parent = Title

local SubLabel = Instance.new("TextLabel")
SubLabel.BackgroundTransparency = 1
SubLabel.Position = UDim2.fromOffset(18, 30)
SubLabel.Size = UDim2.new(1, -90, 0, 14)
SubLabel.Font = Enum.Font.Gotham
SubLabel.TextSize = 11
SubLabel.TextColor3 = Theme.Dim
SubLabel.TextXAlignment = Enum.TextXAlignment.Left
SubLabel.Text = "ESP / FOV / silent aim / wallbang"
SubLabel.Parent = Title

local CloseBtn = Instance.new("TextButton")
CloseBtn.Size = UDim2.fromOffset(30, 30)
CloseBtn.Position = UDim2.new(1, -40, 0, 11)
CloseBtn.BackgroundColor3 = Theme.Row
CloseBtn.AutoButtonColor = false
CloseBtn.BorderSizePixel = 0
CloseBtn.Font = Enum.Font.GothamBold
CloseBtn.TextSize = 13
CloseBtn.TextColor3 = Theme.Dim
CloseBtn.Text = "X"
CloseBtn.Parent = Title
corner(CloseBtn, 8)

local Side = Instance.new("Frame")
Side.Size = UDim2.new(0, 150, 1, -54)
Side.Position = UDim2.fromOffset(0, 54)
Side.BackgroundColor3 = Theme.Side
Side.BorderSizePixel = 0
Side.Parent = Window
corner(Side, 12)

local Pages, TabButtons = {}, {}
local ActiveTab = nil

local function selectTab(name)
	if ActiveTab == name then
		return
	end
	ActiveTab = name
	for tabName, tab in pairs(TabButtons) do
		local on = tabName == name
		tween(tab.Bar, 0.25, { Size = on and UDim2.fromOffset(3, 18) or UDim2.fromOffset(3, 0) })
		tween(tab.Button, 0.2, { TextColor3 = on and Theme.Text or Theme.Dim })
	end
	for tabName, page in pairs(Pages) do
		if tabName == name then
			page.Visible = true
			page.GroupTransparency = 1
			tween(page, 0.3, { GroupTransparency = 0 })
		else
			page.Visible = false
		end
	end
end

local function addPage(name)
	local page = Instance.new("CanvasGroup")
	page.Name = name
	page.Size = UDim2.new(1, -150, 1, -54)
	page.Position = UDim2.fromOffset(150, 54)
	page.BackgroundTransparency = 1
	page.BorderSizePixel = 0
	page.Visible = false
	page.Parent = Window

	local scroll = Instance.new("ScrollingFrame")
	scroll.Size = UDim2.fromScale(1, 1)
	scroll.BackgroundTransparency = 1
	scroll.BorderSizePixel = 0
	scroll.ScrollBarThickness = 3
	scroll.ScrollBarImageColor3 = accentColor()
	scroll.CanvasSize = UDim2.new(0, 0, 0, 0)
	scroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
	scroll.Parent = page
	table.insert(Refreshers, function()
		scroll.ScrollBarImageColor3 = accentColor()
	end)

	local pad = Instance.new("UIPadding")
	pad.PaddingTop = UDim.new(0, 12)
	pad.PaddingLeft = UDim.new(0, 12)
	pad.PaddingRight = UDim.new(0, 12)
	pad.PaddingBottom = UDim.new(0, 12)
	pad.Parent = scroll

	local list = Instance.new("UIListLayout")
	list.Padding = UDim.new(0, 6)
	list.SortOrder = Enum.SortOrder.LayoutOrder
	list.Parent = scroll

	Pages[name] = page
	return scroll
end

local function makeRow(parent, height)
	local row = Instance.new("TextButton")
	row.Size = UDim2.new(1, -4, 0, height)
	row.BackgroundColor3 = Theme.Row
	row.AutoButtonColor = false
	row.BorderSizePixel = 0
	row.Text = ""
	row.Parent = parent
	corner(row, 8)
	bind(row.MouseEnter, function()
		tween(row, 0.15, { BackgroundColor3 = Theme.RowHover })
	end)
	bind(row.MouseLeave, function()
		tween(row, 0.15, { BackgroundColor3 = Theme.Row })
	end)
	return row
end

local function makeLabel(parent, text, size, color, font)
	local l = Instance.new("TextLabel")
	l.BackgroundTransparency = 1
	l.Position = UDim2.fromOffset(12, 0)
	l.Size = UDim2.new(1, -24, 1, 0)
	l.Font = font or Enum.Font.GothamMedium
	l.TextSize = size
	l.TextColor3 = color
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.Text = text
	l.Parent = parent
	return l
end

local function makeHeader(parent, text)
	local l = Instance.new("TextLabel")
	l.Size = UDim2.new(1, -4, 0, 24)
	l.BackgroundTransparency = 1
	l.Font = Enum.Font.GothamBold
	l.TextSize = 11
	l.TextColor3 = Theme.Dim
	l.TextXAlignment = Enum.TextXAlignment.Left
	l.Text = string.upper(text)
	l.Parent = parent
	return l
end

local function makeToggle(parent, label, tbl, key)
	local row = makeRow(parent, 36)
	makeLabel(row, label, 13, Theme.Text)

	local track = Instance.new("Frame")
	track.Size = UDim2.fromOffset(40, 20)
	track.AnchorPoint = Vector2.new(1, 0.5)
	track.Position = UDim2.new(1, -12, 0.5, 0)
	track.BackgroundColor3 = Theme.Off
	track.BorderSizePixel = 0
	track.Parent = row
	corner(track, 10)

	local knob = Instance.new("Frame")
	knob.Size = UDim2.fromOffset(16, 16)
	knob.AnchorPoint = Vector2.new(0, 0.5)
	knob.BackgroundColor3 = Color3.new(1, 1, 1)
	knob.BorderSizePixel = 0
	knob.Parent = track
	corner(knob, 8)

	local function render(instant)
		local on = tbl[key] == true
		local trackColor = on and accentColor() or Theme.Off
		local knobPos = on and UDim2.new(1, -18, 0.5, 0) or UDim2.new(0, 2, 0.5, 0)
		if instant then
			track.BackgroundColor3 = trackColor
			knob.Position = knobPos
		else
			tween(track, 0.25, { BackgroundColor3 = trackColor })
			tween(knob, 0.3, { Position = knobPos }, Enum.EasingStyle.Back)
		end
	end

	bind(row.Activated, function()
		tbl[key] = not tbl[key]
		render(false)
	end)
	table.insert(Refreshers, function()
		render(true)
	end)
	render(true)
	return row
end

local function makeSlider(parent, label, min, max, step, tbl, key)
	local row = makeRow(parent, 52)
	local title = makeLabel(row, label, 13, Theme.Text)
	title.Size = UDim2.new(1, -90, 0, 20)
	title.Position = UDim2.fromOffset(12, 8)

	local valueLbl = makeLabel(row, "", 13, Theme.Dim, Enum.Font.Code)
	valueLbl.Size = UDim2.new(0, 70, 0, 20)
	valueLbl.Position = UDim2.new(1, -82, 0, 8)
	valueLbl.TextXAlignment = Enum.TextXAlignment.Right

	local track = Instance.new("Frame")
	track.Size = UDim2.new(1, -24, 0, 4)
	track.Position = UDim2.fromOffset(12, 36)
	track.BackgroundColor3 = Theme.Off
	track.BorderSizePixel = 0
	track.Parent = row
	corner(track, 2)

	local fill = Instance.new("Frame")
	fill.Size = UDim2.new(0, 0, 1, 0)
	fill.BackgroundColor3 = accentColor()
	fill.BorderSizePixel = 0
	fill.Parent = track
	corner(fill, 2)

	local knob = Instance.new("Frame")
	knob.Size = UDim2.fromOffset(12, 12)
	knob.AnchorPoint = Vector2.new(0.5, 0.5)
	knob.Position = UDim2.new(0, 0, 0.5, 0)
	knob.BackgroundColor3 = Color3.new(1, 1, 1)
	knob.BorderSizePixel = 0
	knob.Parent = track
	corner(knob, 6)

	local hit = Instance.new("TextButton")
	hit.Size = UDim2.new(1, -24, 0, 22)
	hit.Position = UDim2.fromOffset(12, 28)
	hit.BackgroundTransparency = 1
	hit.Text = ""
	hit.AutoButtonColor = false
	hit.Parent = row

	local function render(instant)
		local v = tbl[key]
		local ratio = clamp((v - min) / (max - min), 0, 1)
		valueLbl.Text = tostring(v)
		if instant then
			fill.BackgroundColor3 = accentColor()
			fill.Size = UDim2.new(ratio, 0, 1, 0)
			knob.Position = UDim2.new(ratio, 0, 0.5, 0)
		else
			tween(fill, 0.2, { Size = UDim2.new(ratio, 0, 1, 0), BackgroundColor3 = accentColor() })
			tween(knob, 0.2, { Position = UDim2.new(ratio, 0, 0.5, 0) })
		end
	end

	local dragging = false
	local function setFromX(x)
		local ratio = clamp((x - track.AbsolutePosition.X) / track.AbsoluteSize.X, 0, 1)
		local v = min + math.floor((ratio * (max - min)) / step + 0.5) * step
		tbl[key] = clamp(v, min, max)
		render(true)
	end

	bind(hit.InputBegan, function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 then
			dragging = true
			setFromX(input.Position.X)
		end
	end)
	bind(UIS.InputChanged, function(input)
		if dragging and input.UserInputType == Enum.UserInputType.MouseMovement then
			setFromX(input.Position.X)
		end
	end)
	bind(UIS.InputEnded, function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 then
			dragging = false
		end
	end)
	bind(hit.MouseEnter, function()
		tween(knob, 0.15, { Size = UDim2.fromOffset(14, 14) })
	end)
	bind(hit.MouseLeave, function()
		tween(knob, 0.15, { Size = UDim2.fromOffset(12, 12) })
	end)

	table.insert(Refreshers, function()
		render(true)
	end)
	render(true)
	return row
end

local function makeCycler(parent, label, options, getIndex, setIndex)
	local row = makeRow(parent, 36)
	makeLabel(row, label, 13, Theme.Text)
	local value = makeLabel(row, "", 13, accentColor(), Enum.Font.GothamBold)
	value.TextXAlignment = Enum.TextXAlignment.Right
	local function render()
		value.Text = options[getIndex()]
		value.TextColor3 = accentColor()
	end
	bind(row.Activated, function()
		setIndex(getIndex() % #options + 1)
		render()
		for _, fn in ipairs(Refreshers) do
			fn()
		end
	end)
	table.insert(Refreshers, render)
	render()
	return row
end

local function makeKeybind(parent, label, tbl, key)
	local row = makeRow(parent, 36)
	makeLabel(row, label, 13, Theme.Text)
	local value = makeLabel(row, "", 13, Theme.Dim, Enum.Font.Code)
	value.TextXAlignment = Enum.TextXAlignment.Right
	local function render()
		value.Text = tbl[key].Name
		value.TextColor3 = Theme.Dim
	end
	bind(row.Activated, function()
		value.Text = "press a key"
		value.TextColor3 = accentColor()
		Capture = function(keycode)
			tbl[key] = keycode
			render()
			for _, fn in ipairs(Refreshers) do
				fn()
			end
		end
	end)
	render()
	return row
end

local function makeButton(parent, label, color, fn)
	local row = makeRow(parent, 36)
	local text = makeLabel(row, label, 13, color)
	bind(row.Activated, fn)
	bind(row.MouseEnter, function()
		tween(text, 0.15, { TextTransparency = 0.25 })
	end)
	bind(row.MouseLeave, function()
		tween(text, 0.15, { TextTransparency = 0 })
	end)
	return row
end

local tabNames = { "ESP", "AIM", "SETTINGS" }
for i, name in ipairs(tabNames) do
	local btn = Instance.new("TextButton")
	btn.Size = UDim2.new(1, -16, 0, 38)
	btn.Position = UDim2.fromOffset(8, 12 + (i - 1) * 44)
	btn.BackgroundTransparency = 1
	btn.AutoButtonColor = false
	btn.BorderSizePixel = 0
	btn.Font = Enum.Font.GothamBold
	btn.TextSize = 12
	btn.TextColor3 = Theme.Dim
	btn.TextXAlignment = Enum.TextXAlignment.Left
	btn.Text = "    " .. name
	btn.Parent = Side

	local bar = Instance.new("Frame")
	bar.Size = UDim2.fromOffset(3, 0)
	bar.AnchorPoint = Vector2.new(0, 0.5)
	bar.Position = UDim2.new(0, 0, 0.5, 0)
	bar.BackgroundColor3 = accentColor()
	bar.BorderSizePixel = 0
	bar.Parent = btn
	corner(bar, 2)

	table.insert(Refreshers, function()
		bar.BackgroundColor3 = accentColor()
	end)
	bind(btn.Activated, function()
		selectTab(name)
	end)
	bind(btn.MouseEnter, function()
		if ActiveTab ~= name then
			tween(btn, 0.15, { TextColor3 = Theme.Text })
		end
	end)
	bind(btn.MouseLeave, function()
		if ActiveTab ~= name then
			tween(btn, 0.15, { TextColor3 = Theme.Dim })
		end
	end)
	TabButtons[name] = { Button = btn, Bar = bar }
end

local espPage = addPage("ESP")
makeHeader(espPage, "Player ESP")
makeToggle(espPage, "ESP enabled", Config.ESP, "Enabled")
makeToggle(espPage, "Box", Config.ESP, "Box")
makeToggle(espPage, "Skeleton", Config.ESP, "Skeleton")
makeToggle(espPage, "Health bar", Config.ESP, "Healthbar")
makeToggle(espPage, "Name / role", Config.ESP, "Name")
makeToggle(espPage, "Distance", Config.ESP, "Distance")
makeToggle(espPage, "Tracers", Config.ESP, "Tracer")
makeToggle(espPage, "Chams (wallhack fill)", Config.ESP, "Chams")
makeHeader(espPage, "Filters")
makeToggle(espPage, "Team check", Config, "TeamCheck")
makeSlider(espPage, "Max distance", 100, 5000, 50, Config.ESP, "MaxDistance")

local aimPage = addPage("AIM")
makeHeader(aimPage, "Silent aim")
makeToggle(aimPage, "Silent aim", Config.Aim, "SilentAim")
makeToggle(aimPage, "Wallbang (through walls)", Config.Aim, "Wallbang")
makeToggle(aimPage, "Fire check (LMB held only)", Config.Aim, "FireCheck")
makeToggle(aimPage, "Visible only (off with wallbang)", Config.Aim, "VisibleOnly")
makeHeader(aimPage, "FOV wheel")
makeSlider(aimPage, "FOV radius", 40, 400, 5, Config.Aim, "FOVRadius")
makeToggle(aimPage, "Show wheel", Config.Aim, "ShowFOV")
makeToggle(aimPage, "Pulse animation", Config.Aim, "Pulse")
makeToggle(aimPage, "Rotating ticks", Config.Aim, "Ticks")
makeToggle(aimPage, "Center dot", Config.Aim, "CenterDot")
makeToggle(aimPage, "Head line", Config.Aim, "Line")
makeToggle(aimPage, "Travelling pulse on line", Config.Aim, "Travel")

local setPage = addPage("SETTINGS")
makeHeader(setPage, "Menu")
makeKeybind(setPage, "Menu key", Config.Menu, "Key")
makeCycler(setPage, "Accent", (function()
	local names = {}
	for _, a in ipairs(Accents) do
		table.insert(names, a.Name)
	end
	return names
end)(), function()
	return Config.Menu.Accent
end, function(v)
	Config.Menu.Accent = v
end)
makeHeader(setPage, "Session")
local unloadRow = makeButton(setPage, "Unload suite", Theme.Danger, function()
	unload()
end)
unloadRow.Name = "Unload"

table.insert(Refreshers, function()
	AccentLine.BackgroundColor3 = accentColor()
end)

local Dragging, DragStart, StartPos = false, nil, nil
bind(Title.InputBegan, function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		Dragging = true
		DragStart = input.Position
		StartPos = Window.Position
	end
end)
bind(UIS.InputChanged, function(input)
	if Dragging and input.UserInputType == Enum.UserInputType.MouseMovement then
		local d = input.Position - DragStart
		Window.Position = UDim2.new(StartPos.X.Scale, StartPos.X.Offset + d.X, StartPos.Y.Scale, StartPos.Y.Offset + d.Y)
	end
end)
bind(UIS.InputEnded, function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		Dragging = false
	end
end)

local Visible = true

local function setMenu(open)
	Visible = open
	if open then
		Window.Visible = true
		Window.GroupTransparency = 1
		WindowScale.Scale = 0.92
		tween(Window, 0.3, { GroupTransparency = 0 })
		tween(WindowScale, 0.4, { Scale = 1 }, Enum.EasingStyle.Back)
	else
		local tw = tween(Window, 0.2, { GroupTransparency = 1 })
		tween(WindowScale, 0.2, { Scale = 0.94 })
		bind(tw.Completed, function()
			if not Visible then
				Window.Visible = false
			end
		end)
	end
end

bind(CloseBtn.Activated, function()
	setMenu(false)
end)
bind(CloseBtn.MouseEnter, function()
	tween(CloseBtn, 0.15, { TextColor3 = Theme.Danger })
end)
bind(CloseBtn.MouseLeave, function()
	tween(CloseBtn, 0.15, { TextColor3 = Theme.Dim })
end)

bind(UIS.InputBegan, function(input)
	if Capture and input.UserInputType == Enum.UserInputType.Keyboard then
		local cb = Capture
		Capture = nil
		cb(input.KeyCode)
		return
	end
	if input.KeyCode == Config.Menu.Key then
		setMenu(not Visible)
	end
end)

selectTab("ESP")
setMenu(true)

unload = function()
	if Unloaded then
		return
	end
	Unloaded = true
	for _, c in ipairs(Connections) do
		c:Disconnect()
	end
	for model, store in pairs(Entities) do
		destroyStore(store)
		Entities[model] = nil
	end
	Overlay.Ring:Remove()
	Overlay.Dot:Remove()
	Overlay.HeadRing:Remove()
	Overlay.Line:Remove()
	Overlay.Travel:Remove()
	for _, t in ipairs(Overlay.Ticks) do
		t:Remove()
	end
	Gui:Destroy()
	HighlightFolder:Destroy()
	env.__SHOOTER_SUITE_UNLOAD = nil
end
env.__SHOOTER_SUITE_UNLOAD = unload
