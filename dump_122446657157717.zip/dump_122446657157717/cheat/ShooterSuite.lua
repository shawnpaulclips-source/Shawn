--// ShooterSuite v2 — mapped live against place 122446657157717
--//   Players -> Workspace.<Name> (R15). Stats are attributes on the Player object:
--//              Health, MaxHealth, Shield, Team, State, World, GameRoom
--//   Bots    -> Workspace.World.<roomId>.Entities.<Model>, same attributes on the model,
--//              hitbox parts under .Collider (Head / Body / Arm / Leg)
--//   Mode    -> Workspace.Room.<GameRoom>.Data.Mode   (FFA_* modes put everyone on Team3)
--//   Aiming  -> ReplicatedStorage.Client.CameraController.GetTargeting() -> (hitPos, hitPart)
--//              ClientShootableComponent reads GetTargetingFn()() -> (ok, hitPos, hitPart)
--//              and flags TargetHeadshot from hitPart.Name == "Head"

local env = (getgenv and getgenv()) or _G
if env.__SHOOTER_SUITE_UNLOAD then
	pcall(env.__SHOOTER_SUITE_UNLOAD)
end

assert(Drawing and Drawing.new, "ShooterSuite: Drawing library not available")

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UIS = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local HttpService = game:GetService("HttpService")
local CoreGui = game:GetService("CoreGui")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local LocalPlayer = Players.LocalPlayer
local ProtectedRoot = (gethui and gethui()) or CoreGui
local RENDER_NAME = "SS_MouseFree_" .. tostring(math.random(1e5, 9e5))

local function findPath(root, ...)
	local node = root
	for _, name in ipairs({ ... }) do
		node = node and node:FindFirstChild(name)
	end
	return node
end

local function safeRequire(...)
	local m = findPath(ReplicatedStorage, ...)
	if not m then
		return nil
	end
	local ok, mod = pcall(require, m)
	return ok and mod or nil
end

local CameraController = safeRequire("Client", "CameraController")
local EntityService = safeRequire("Remote", "EntityService")

--// ───────────── Targeting hooks (installed once per session, re-pointed on reload) ─────────────

local Shared = env.__SHOOTER_SUITE_SHARED
if type(Shared) ~= "table" then
	Shared = { Redirect = nil, Hooked = false, HookOk = false, HookError = nil }
	env.__SHOOTER_SUITE_SHARED = Shared
end

local function currentRedirect()
	local fn = Shared.Redirect
	if not fn then
		return nil
	end
	local ok, part = pcall(fn)
	if ok and typeof(part) == "Instance" and part.Parent then
		return part
	end
	return nil
end

local function installHook(fn, replacement)
	if iscclosure and iscclosure(fn) and newcclosure then
		replacement = newcclosure(replacement)
	end
	return hookfunction(fn, replacement)
end

if not Shared.Hooked then
	Shared.Hooked = true
	if CameraController and hookfunction then
		local ok, err = pcall(function()
			local getTargeting = CameraController.GetTargeting
			local getTargetingFn = CameraController.GetTargetingFn
			assert(type(getTargeting) == "function", "CameraController.GetTargeting missing")

			local oldGetTargeting
			oldGetTargeting = installHook(getTargeting, function(...)
				local part = currentRedirect()
				if part then
					return part.Position, part
				end
				return oldGetTargeting(...)
			end)

			if type(getTargetingFn) == "function" then
				local okInner, inner = pcall(getTargetingFn)
				if okInner and type(inner) == "function" and inner ~= getTargeting then
					local oldInner
					oldInner = installHook(inner, function(...)
						local part = currentRedirect()
						if part then
							return true, part.Position, part
						end
						return oldInner(...)
					end)
				end
				local oldFn
				oldFn = installHook(getTargetingFn, function(...)
					local innerFn = oldFn(...)
					if type(innerFn) ~= "function" then
						return innerFn
					end
					return function(...)
						local part = currentRedirect()
						if part then
							return true, part.Position, part
						end
						return innerFn(...)
					end
				end)
			end
		end)
		Shared.HookOk = ok
		Shared.HookError = (not ok) and tostring(err) or nil
	else
		Shared.HookError = CameraController and "hookfunction missing" or "CameraController not found"
	end
end

--// ───────────── Config ─────────────

local Palette = {
	{ Name = "Ember", Color = Color3.fromRGB(255, 106, 61) },
	{ Name = "Acid", Color = Color3.fromRGB(178, 238, 86) },
	{ Name = "Iris", Color = Color3.fromRGB(140, 122, 255) },
	{ Name = "Tide", Color = Color3.fromRGB(70, 198, 255) },
	{ Name = "Rose", Color = Color3.fromRGB(255, 88, 150) },
	{ Name = "Bone", Color = Color3.fromRGB(236, 230, 214) },
}

local Config = {
	TeamCheck = true,
	SameMatch = true,
	ESP = {
		Enabled = true,
		Box = true,
		Skeleton = true,
		Healthbar = true,
		Name = true,
		Distance = true,
		Tracer = false,
		Chams = false,
		ShowTeam = false,
		VisTint = true,
		MaxDistance = 1500,
		EnemyColor = 1,
		TeamColor = 4,
	},
	Aim = {
		SilentAim = false,
		FireCheck = true,
		VisibleOnly = true,
		Part = 1,
		FOVRadius = 140,
		MaxDistance = 1000,
		ShowFOV = true,
		FillFOV = true,
		Ticks = true,
		Line = true,
		Marker = true,
	},
	Menu = {
		Key = "RightShift",
		Accent = 1,
		Pill = true,
	},
}

local CONFIG_FILE = "ShooterSuite.json"

local function deepMerge(dst, src)
	for k, v in pairs(src) do
		if type(v) == "table" and type(dst[k]) == "table" then
			deepMerge(dst[k], v)
		elseif dst[k] ~= nil and type(dst[k]) == type(v) then
			dst[k] = v
		end
	end
end

if readfile and isfile then
	pcall(function()
		if isfile(CONFIG_FILE) then
			deepMerge(Config, HttpService:JSONDecode(readfile(CONFIG_FILE)))
		end
	end)
end
for _, ref in ipairs({ { Config.Menu, "Accent" }, { Config.ESP, "EnemyColor" }, { Config.ESP, "TeamColor" } }) do
	if not Palette[ref[1][ref[2]]] then
		ref[1][ref[2]] = 1
	end
end
if not pcall(function()
	return Enum.KeyCode[Config.Menu.Key]
end) then
	Config.Menu.Key = "RightShift"
end

local Dirty = false
local function markDirty()
	Dirty = true
end
local function saveConfig()
	Dirty = false
	if writefile then
		pcall(writefile, CONFIG_FILE, HttpService:JSONEncode(Config))
	end
end

local function paletteColor(i)
	return (Palette[i] or Palette[1]).Color
end
local function accent()
	return paletteColor(Config.Menu.Accent)
end
local function menuKey()
	local ok, kc = pcall(function()
		return Enum.KeyCode[Config.Menu.Key]
	end)
	return ok and kc or Enum.KeyCode.RightShift
end
local function keyLabel(name)
	return (name:gsub("^Right", "R"):gsub("^Left", "L"):gsub("Control", "Ctrl"))
end

--// ───────────── Runtime state ─────────────

local Unloaded = false
local Connections = {}
local Targets = {}
local ModeName = nil
local LockedTarget, LockedPart, LockedScreen = nil, nil, nil
local unload

local function bind(signal, fn)
	local c = signal:Connect(fn)
	table.insert(Connections, c)
	return c
end

local function clamp(v, lo, hi)
	return math.max(lo, math.min(hi, v))
end

local function newDraw(class, props)
	local d = Drawing.new(class)
	d.Transparency = 1
	for k, v in pairs(props or {}) do
		d[k] = v
	end
	d.Visible = false
	return d
end

local HighlightFolder = Instance.new("Folder")
HighlightFolder.Name = HttpService:GenerateGUID(false):sub(1, 8)
HighlightFolder.Parent = ProtectedRoot

local R15_BONES = {
	{ "Head", "UpperTorso" },
	{ "UpperTorso", "LowerTorso" },
	{ "UpperTorso", "LeftUpperArm" },
	{ "LeftUpperArm", "LeftLowerArm" },
	{ "LeftLowerArm", "LeftHand" },
	{ "UpperTorso", "RightUpperArm" },
	{ "RightUpperArm", "RightLowerArm" },
	{ "RightLowerArm", "RightHand" },
	{ "LowerTorso", "LeftUpperLeg" },
	{ "LeftUpperLeg", "LeftLowerLeg" },
	{ "LeftLowerLeg", "LeftFoot" },
	{ "LowerTorso", "RightUpperLeg" },
	{ "RightUpperLeg", "RightLowerLeg" },
	{ "RightLowerLeg", "RightFoot" },
}
local MAX_BONES = #R15_BONES

local function newStore()
	local s = {
		Shown = false,
		BoxOutline = newDraw("Square", { Thickness = 3, Filled = false, Color = Color3.new(0, 0, 0), Transparency = 0.55 }),
		Box = newDraw("Square", { Thickness = 1, Filled = false }),
		HPBack = newDraw("Square", { Filled = true, Color = Color3.new(0, 0, 0), Transparency = 0.7 }),
		HPFill = newDraw("Square", { Filled = true }),
		Name = newDraw("Text", { Size = 13, Center = true, Outline = true, Font = 2 }),
		Info = newDraw("Text", { Size = 12, Center = true, Outline = true, Font = 2, Color = Color3.fromRGB(196, 196, 208) }),
		Tracer = newDraw("Line", { Thickness = 1, Transparency = 0.7 }),
		Bones = {},
		Highlight = Instance.new("Highlight"),
	}
	for i = 1, MAX_BONES do
		s.Bones[i] = newDraw("Line", { Thickness = 1 })
	end
	local hl = s.Highlight
	hl.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
	hl.FillTransparency = 0.65
	hl.OutlineTransparency = 0.1
	hl.Enabled = false
	hl.Parent = HighlightFolder
	return s
end

local function hideStore(s)
	if not s.Shown then
		return
	end
	s.Shown = false
	s.Box.Visible = false
	s.BoxOutline.Visible = false
	s.HPBack.Visible = false
	s.HPFill.Visible = false
	s.Name.Visible = false
	s.Info.Visible = false
	s.Tracer.Visible = false
	for _, b in ipairs(s.Bones) do
		b.Visible = false
	end
	s.Highlight.Enabled = false
end

local function destroyStore(s)
	for _, k in ipairs({ "Box", "BoxOutline", "HPBack", "HPFill", "Name", "Info", "Tracer" }) do
		pcall(s[k].Remove, s[k])
	end
	for _, b in ipairs(s.Bones) do
		pcall(b.Remove, b)
	end
	s.Highlight:Destroy()
end

local function buildCache(t)
	local m = t.Model
	if not m or not m.Parent then
		return nil
	end
	local c = { Bones = {}, Extents = {} }
	if t.Kind == "Player" then
		c.Head = m:FindFirstChild("Head")
		c.Root = m:FindFirstChild("HumanoidRootPart")
		c.Torso = m:FindFirstChild("UpperTorso") or m:FindFirstChild("Torso") or c.Root
		for _, pair in ipairs(R15_BONES) do
			local a, b = m:FindFirstChild(pair[1]), m:FindFirstChild(pair[2])
			if a and b then
				table.insert(c.Bones, { a, b })
			end
		end
		for _, n in ipairs({ "LeftFoot", "RightFoot", "Left Leg", "Right Leg" }) do
			local p = m:FindFirstChild(n)
			if p then
				table.insert(c.Extents, p)
			end
		end
	else
		local col = m:FindFirstChild("Collider")
		c.Head = col and col:FindFirstChild("Head")
		c.Root = m:FindFirstChild("HumanoidRootPart") or (col and col:FindFirstChild("HumanoidRootPart"))
		local body = col and col:FindFirstChild("Body")
		c.Torso = body or c.Root
		if col then
			if body and c.Head then
				table.insert(c.Bones, { c.Head, body })
			end
			for _, p in ipairs(col:GetChildren()) do
				if p:IsA("BasePart") and (p.Name == "Arm" or p.Name == "Leg") then
					if body then
						table.insert(c.Bones, { body, p })
					end
					if p.Name == "Leg" then
						table.insert(c.Extents, p)
					end
				end
			end
		end
	end
	if not (c.Head and c.Root) then
		return nil
	end
	if #c.Extents == 0 then
		table.insert(c.Extents, c.Root)
	end
	return c
end

local function currentMode()
	local id = LocalPlayer:GetAttribute("GameRoom")
	local mode = id and findPath(Workspace, "Room", tostring(id), "Data", "Mode")
	return mode and mode.Value or nil
end

local function localEntity()
	if not EntityService or type(EntityService.GetLocalEntity) ~= "function" then
		return nil
	end
	local ok, e = pcall(EntityService.GetLocalEntity)
	return (ok and type(e) == "table") and e or nil
end

local function gameEntity(t)
	if not EntityService then
		return nil
	end
	local ok, e
	if t.Kind == "Player" and type(EntityService.GetEntity) == "function" then
		ok, e = pcall(EntityService.GetEntity, t.Player)
	elseif t.Cache and type(EntityService.FetchEntity) == "function" then
		ok, e = pcall(EntityService.FetchEntity, t.Cache.Head)
	end
	return (ok and type(e) == "table") and e or nil
end

local function computeFriendly(t, le)
	if type(ModeName) == "string" and ModeName:sub(1, 3) == "FFA" then
		return false
	end
	local e = le and gameEntity(t)
	if e and type(le.IsFriendly) == "function" then
		local ok, r = pcall(le.IsFriendly, le, e)
		if ok and type(r) == "boolean" then
			return r
		end
	end
	local mine, theirs = LocalPlayer:GetAttribute("Team"), t.Source:GetAttribute("Team")
	return mine ~= nil and theirs ~= nil and mine == theirs
end

local function sameWorld(t)
	if not Config.SameMatch then
		return true
	end
	local mine, theirs = LocalPlayer:GetAttribute("World"), t.Source:GetAttribute("World")
	return mine == nil or theirs == nil or mine == theirs
end

local function registerTarget(key, kind, source, player, model)
	local t = { Key = key, Kind = kind, Source = source, Player = player, Model = model, Store = newStore() }
	Targets[key] = t
	return t
end

local function refreshTargets()
	ModeName = currentMode()
	local seen = {}
	for _, plr in ipairs(Players:GetPlayers()) do
		if plr ~= LocalPlayer then
			local char = plr.Character
			if char and char.Parent then
				seen[plr] = true
				local t = Targets[plr] or registerTarget(plr, "Player", plr, plr, char)
				t.Model = char
			end
		end
	end
	local worlds = Workspace:FindFirstChild("World")
	if worlds then
		for _, w in ipairs(worlds:GetChildren()) do
			local ents = w:FindFirstChild("Entities")
			if ents then
				for _, m in ipairs(ents:GetChildren()) do
					if m:IsA("Model") and m:FindFirstChild("Collider") and not Players:GetPlayerFromCharacter(m) then
						seen[m] = true
						if not Targets[m] then
							registerTarget(m, "Bot", m, nil, m)
						end
					end
				end
			end
		end
	end
	for key, t in pairs(Targets) do
		if not seen[key] then
			destroyStore(t.Store)
			Targets[key] = nil
		end
	end
	local le = localEntity()
	for _, t in pairs(Targets) do
		t.Cache = buildCache(t)
		t.Store.Highlight.Adornee = t.Model
		t.Name = (t.Kind == "Player") and t.Player.DisplayName or t.Model.Name
		t.Friendly = computeFriendly(t, le)
		t.InWorld = sameWorld(t)
	end
end

local function readStats(t)
	local src = t.Source
	local hp, maxhp = src:GetAttribute("Health"), src:GetAttribute("MaxHealth")
	if type(hp) ~= "number" then
		local hum = t.Model:FindFirstChildOfClass("Humanoid")
		hp = hum and hum.Health or 0
		maxhp = hum and hum.MaxHealth or 100
	end
	if type(maxhp) ~= "number" or maxhp <= 0 then
		maxhp = math.max(hp, 1)
	end
	return hp, maxhp, hp > 0 and src:GetAttribute("State") ~= "Dead"
end

local visParams = RaycastParams.new()
visParams.FilterType = Enum.RaycastFilterType.Exclude
visParams.IgnoreWater = true

local function isVisible(part, model, origin)
	local cam = Workspace.CurrentCamera
	local ignore = { cam, model }
	if LocalPlayer.Character then
		table.insert(ignore, LocalPlayer.Character)
	end
	for _, n in ipairs({ "Highlight", "_Temp" }) do
		local f = Workspace:FindFirstChild(n)
		if f then
			table.insert(ignore, f)
		end
	end
	visParams.FilterDescendantsInstances = ignore
	return Workspace:Raycast(origin, part.Position - origin, visParams) == nil
end

local function toScreen(pos)
	local v = Workspace.CurrentCamera:WorldToViewportPoint(pos)
	return Vector2.new(v.X, v.Y), v.Z > 0
end

local function aimPartOf(t)
	local c = t.Cache
	if not c then
		return nil
	end
	return (Config.Aim.Part == 2) and c.Torso or c.Head
end

local function pickTarget(mouse, camPos)
	local aim = Config.Aim
	local cands = {}
	for _, t in pairs(Targets) do
		if t.Targetable and t.Distance <= aim.MaxDistance then
			local part = aimPartOf(t)
			if part and part.Parent then
				local sp, on = toScreen(part.Position)
				if on then
					local d = (sp - mouse).Magnitude
					if d <= aim.FOVRadius then
						table.insert(cands, { T = t, Part = part, D = d, Screen = sp })
					end
				end
			end
		end
	end
	table.sort(cands, function(a, b)
		return a.D < b.D
	end)
	for _, c in ipairs(cands) do
		if not aim.VisibleOnly or isVisible(c.Part, c.T.Model, camPos) then
			return c.T, c.Part, c.Screen
		end
	end
	return nil, nil, nil
end

Shared.Redirect = function()
	if Unloaded or not Config.Aim.SilentAim then
		return nil
	end
	if Config.Aim.FireCheck and not UIS:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) then
		return nil
	end
	return LockedPart
end

local function boundsOf(c, cam)
	local rp = c.Root.Position
	local topY = c.Head.Position.Y + c.Head.Size.Y * 0.65
	local botY = math.huge
	for _, p in ipairs(c.Extents) do
		if p.Parent then
			local y = p.Position.Y - p.Size.Y * 0.5
			if y < botY then
				botY = y
			end
		end
	end
	if botY == math.huge or botY > rp.Y then
		botY = rp.Y - c.Root.Size.Y * 1.5
	end
	local top = cam:WorldToViewportPoint(Vector3.new(rp.X, topY, rp.Z))
	local bot = cam:WorldToViewportPoint(Vector3.new(rp.X, botY, rp.Z))
	if top.Z <= 0 or bot.Z <= 0 then
		return nil
	end
	local h = math.max(bot.Y - top.Y, 6)
	local w = math.max(h * 0.52, 4)
	local cx = (top.X + bot.X) * 0.5
	return math.floor(cx - w * 0.5), math.floor(top.Y), math.floor(w), math.floor(h)
end

local WHITE = Color3.new(1, 1, 1)
local SHADE = Color3.fromRGB(60, 60, 70)

local function drawESP(t, cam, camPos)
	local esp = Config.ESP
	local s, c = t.Store, t.Cache
	local x, y, w, h = boundsOf(c, cam)
	if not x then
		hideStore(s)
		return
	end
	s.Shown = true

	local color = t.Friendly and paletteColor(esp.TeamColor) or paletteColor(esp.EnemyColor)
	if esp.VisTint and not isVisible(c.Head, t.Model, camPos) then
		color = color:Lerp(SHADE, 0.45)
	end
	if t == LockedTarget then
		color = color:Lerp(WHITE, 0.55)
	end

	s.Box.Visible = esp.Box
	s.BoxOutline.Visible = esp.Box
	if esp.Box then
		s.Box.Position = Vector2.new(x, y)
		s.Box.Size = Vector2.new(w, h)
		s.Box.Color = color
		s.BoxOutline.Position = Vector2.new(x, y)
		s.BoxOutline.Size = Vector2.new(w, h)
	end

	s.HPBack.Visible = esp.Healthbar
	s.HPFill.Visible = esp.Healthbar
	if esp.Healthbar then
		local ratio = clamp(t.HP / t.MaxHP, 0, 1)
		s.HPBack.Position = Vector2.new(x - 7, y - 1)
		s.HPBack.Size = Vector2.new(4, h + 2)
		s.HPFill.Position = Vector2.new(x - 6, y + math.floor(h * (1 - ratio)))
		s.HPFill.Size = Vector2.new(2, math.max(math.floor(h * ratio), 1))
		s.HPFill.Color = ratio > 0.5 and Color3.fromRGB(255, 214, 72):Lerp(Color3.fromRGB(96, 232, 132), (ratio - 0.5) * 2)
			or Color3.fromRGB(240, 72, 72):Lerp(Color3.fromRGB(255, 214, 72), ratio * 2)
	end

	s.Name.Visible = esp.Name
	if esp.Name then
		s.Name.Text = t.Name
		s.Name.Position = Vector2.new(x + w * 0.5, y - 16)
		s.Name.Color = (t == LockedTarget) and accent() or Color3.fromRGB(240, 240, 245)
	end

	s.Info.Visible = esp.Distance
	if esp.Distance then
		s.Info.Text = string.format("%dm  ·  %d hp", math.floor(t.Distance), math.floor(t.HP))
		s.Info.Position = Vector2.new(x + w * 0.5, y + h + 3)
	end

	s.Tracer.Visible = esp.Tracer
	if esp.Tracer then
		local vp = cam.ViewportSize
		s.Tracer.From = Vector2.new(vp.X * 0.5, vp.Y - 2)
		s.Tracer.To = Vector2.new(x + w * 0.5, y + h)
		s.Tracer.Color = color
	end

	for i = 1, MAX_BONES do
		local bone, seg = s.Bones[i], c.Bones[i]
		if esp.Skeleton and seg and seg[1].Parent and seg[2].Parent then
			local a, aOn = toScreen(seg[1].Position)
			local b, bOn = toScreen(seg[2].Position)
			bone.Visible = aOn and bOn
			bone.From = a
			bone.To = b
			bone.Color = color
		else
			bone.Visible = false
		end
	end

	s.Highlight.Enabled = esp.Chams
	if esp.Chams then
		s.Highlight.FillColor = color
		s.Highlight.OutlineColor = color
	end
end

local Overlay = {
	Fill = newDraw("Circle", { Filled = true, NumSides = 96, Thickness = 1, Transparency = 0.05 }),
	Ring = newDraw("Circle", { Filled = false, NumSides = 128, Thickness = 1.5 }),
	Line = newDraw("Line", { Thickness = 1.5, Transparency = 0.55 }),
	Marker = newDraw("Circle", { Filled = false, NumSides = 32, Thickness = 1.5 }),
	MarkerDot = newDraw("Circle", { Filled = true, NumSides = 16, Radius = 2, Color = WHITE }),
	Label = newDraw("Text", { Size = 13, Center = true, Outline = true, Font = 2 }),
	Ticks = {},
}
for i = 1, 4 do
	Overlay.Ticks[i] = newDraw("Line", { Thickness = 2 })
end

local function drawOverlay(t, mouse)
	local aim = Config.Aim
	local a = accent()
	local pulse = (math.sin(t * 3) + 1) * 0.5
	local r = aim.FOVRadius

	Overlay.Ring.Visible = aim.ShowFOV
	Overlay.Ring.Position = mouse
	Overlay.Ring.Radius = r
	Overlay.Ring.Color = a
	Overlay.Ring.Transparency = LockedTarget and 0.95 or (0.45 + 0.3 * pulse)

	Overlay.Fill.Visible = aim.ShowFOV and aim.FillFOV
	Overlay.Fill.Position = mouse
	Overlay.Fill.Radius = r
	Overlay.Fill.Color = a

	for i, tick in ipairs(Overlay.Ticks) do
		local ang = t * 0.9 + (i - 1) * math.pi * 0.5
		local dir = Vector2.new(math.cos(ang), math.sin(ang))
		tick.Visible = aim.ShowFOV and aim.Ticks
		tick.From = mouse + dir * (r - 8)
		tick.To = mouse + dir * (r - 1)
		tick.Color = a
	end

	if LockedTarget and LockedScreen then
		Overlay.Line.Visible = aim.Line
		Overlay.Line.From = mouse
		Overlay.Line.To = LockedScreen
		Overlay.Line.Color = a
		Overlay.Marker.Visible = aim.Marker
		Overlay.Marker.Position = LockedScreen
		Overlay.Marker.Radius = 6 + pulse * 3
		Overlay.Marker.Color = a
		Overlay.MarkerDot.Visible = aim.Marker
		Overlay.MarkerDot.Position = LockedScreen
		Overlay.Label.Visible = aim.ShowFOV
		Overlay.Label.Text = (Config.Aim.SilentAim and "LOCK  " or "TRACK  ") .. string.upper(LockedTarget.Name)
		Overlay.Label.Position = mouse + Vector2.new(0, r + 8)
		Overlay.Label.Color = a
	else
		Overlay.Line.Visible = false
		Overlay.Marker.Visible = false
		Overlay.MarkerDot.Visible = false
		Overlay.Label.Visible = false
	end
end

--// ───────────── UI ─────────────

local Theme = {
	Bg = Color3.fromRGB(13, 13, 16),
	Rail = Color3.fromRGB(17, 17, 21),
	Panel = Color3.fromRGB(21, 21, 26),
	PanelHover = Color3.fromRGB(29, 29, 36),
	Line = Color3.fromRGB(34, 34, 42),
	Stroke = Color3.fromRGB(44, 44, 54),
	Text = Color3.fromRGB(236, 236, 241),
	Sub = Color3.fromRGB(150, 150, 164),
	Faint = Color3.fromRGB(92, 92, 106),
	Off = Color3.fromRGB(46, 46, 56),
	Danger = Color3.fromRGB(240, 86, 96),
}

local function family(name, weight)
	local ok, f = pcall(Font.new, "rbxasset://fonts/families/" .. name .. ".json", weight)
	return ok and f or Font.fromEnum(Enum.Font.Gotham)
end
local Fonts = {
	Regular = family("GothamSSm", Enum.FontWeight.Regular),
	Medium = family("GothamSSm", Enum.FontWeight.Medium),
	Bold = family("GothamSSm", Enum.FontWeight.Bold),
	Heavy = family("GothamSSm", Enum.FontWeight.Heavy),
	Mono = family("RobotoMono", Enum.FontWeight.Medium),
}

local function tween(obj, time, props, style, dir)
	local tw = TweenService:Create(obj, TweenInfo.new(time, style or Enum.EasingStyle.Quint, dir or Enum.EasingDirection.Out), props)
	tw:Play()
	return tw
end

local function new(class, props, children)
	local inst = Instance.new(class)
	for k, v in pairs(props or {}) do
		if k ~= "Parent" then
			inst[k] = v
		end
	end
	for _, ch in ipairs(children or {}) do
		ch.Parent = inst
	end
	if props and props.Parent then
		inst.Parent = props.Parent
	end
	return inst
end

local function corner(r)
	return new("UICorner", { CornerRadius = UDim.new(0, r) })
end
local function stroke(color, th, tr)
	return new("UIStroke", { Color = color, Thickness = th or 1, Transparency = tr or 0, ApplyStrokeMode = Enum.ApplyStrokeMode.Border })
end
local function pad(t, r, b, l)
	return new("UIPadding", { PaddingTop = UDim.new(0, t), PaddingRight = UDim.new(0, r), PaddingBottom = UDim.new(0, b), PaddingLeft = UDim.new(0, l) })
end
local function label(props)
	local base = {
		BackgroundTransparency = 1,
		BorderSizePixel = 0,
		FontFace = Fonts.Medium,
		TextSize = 13,
		TextColor3 = Theme.Text,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextYAlignment = Enum.TextYAlignment.Center,
	}
	for k, v in pairs(props) do
		base[k] = v
	end
	return new("TextLabel", base)
end

local Refreshers = {}
local function refreshAll()
	for _, fn in ipairs(Refreshers) do
		pcall(fn, false)
	end
end

local Gui = new("ScreenGui", {
	Name = HttpService:GenerateGUID(false):sub(1, 8),
	ResetOnSpawn = false,
	IgnoreGuiInset = true,
	ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
	DisplayOrder = 10000,
})
if syn and syn.protect_gui then
	pcall(syn.protect_gui, Gui)
end
Gui.Parent = ProtectedRoot

local WIN_W, WIN_H, RAIL_W, TAB_STEP = 660, 460, 184, 42

local Holder = new("Frame", {
	AnchorPoint = Vector2.new(0.5, 0.5),
	Position = UDim2.fromScale(0.5, 0.5),
	Size = UDim2.fromOffset(WIN_W, WIN_H),
	BackgroundTransparency = 1,
	Parent = Gui,
})
local HolderScale = new("UIScale", { Parent = Holder })

local ShadowLayers = {}
for i, base in ipairs({ 0.86, 0.92, 0.96 }) do
	local grow = i * 8
	local sh = new("Frame", {
		AnchorPoint = Vector2.new(0.5, 0.5),
		Position = UDim2.new(0.5, 0, 0.5, 6),
		Size = UDim2.new(1, grow, 1, grow),
		BackgroundColor3 = Color3.new(0, 0, 0),
		BackgroundTransparency = base,
		BorderSizePixel = 0,
		ZIndex = 0,
		Parent = Holder,
	}, { corner(14 + grow // 2) })
	table.insert(ShadowLayers, { Frame = sh, Base = base })
end

local Window = new("CanvasGroup", {
	Size = UDim2.fromScale(1, 1),
	BackgroundColor3 = Theme.Bg,
	BorderSizePixel = 0,
	Parent = Holder,
}, { corner(14), stroke(Theme.Stroke, 1) })

new("TextButton", { Size = UDim2.fromOffset(0, 0), BackgroundTransparency = 1, Text = "", Modal = true, Parent = Window })

-- Rail
local Rail = new("Frame", { Size = UDim2.new(0, RAIL_W, 1, 0), BackgroundColor3 = Theme.Rail, BorderSizePixel = 0, Parent = Window })
new("Frame", { Size = UDim2.new(0, 1, 1, 0), Position = UDim2.new(1, -1, 0, 0), BackgroundColor3 = Theme.Line, BorderSizePixel = 0, Parent = Rail })

local Brand = new("Frame", { Size = UDim2.new(1, 0, 0, 70), BackgroundTransparency = 1, Parent = Rail })
local Logo = new("Frame", { Size = UDim2.fromOffset(32, 32), Position = UDim2.fromOffset(18, 20), BackgroundColor3 = WHITE, BorderSizePixel = 0, Parent = Brand }, { corner(10) })
local LogoGrad = new("UIGradient", { Rotation = 45, Parent = Logo })
label({ Parent = Logo, Size = UDim2.fromScale(1, 1), Text = "S", FontFace = Fonts.Heavy, TextSize = 17, TextColor3 = Theme.Bg, TextXAlignment = Enum.TextXAlignment.Center })
label({ Parent = Brand, Position = UDim2.fromOffset(60, 20), Size = UDim2.new(1, -70, 0, 17), Text = "ShooterSuite", FontFace = Fonts.Bold, TextSize = 14 })
label({ Parent = Brand, Position = UDim2.fromOffset(60, 38), Size = UDim2.new(1, -70, 0, 14), Text = "v2 · live mapped", FontFace = Fonts.Regular, TextSize = 11, TextColor3 = Theme.Faint })
table.insert(Refreshers, function()
	local a = accent()
	LogoGrad.Color = ColorSequence.new(a, a:Lerp(Color3.new(0, 0, 0), 0.35))
end)

local TabList = new("Frame", { Position = UDim2.fromOffset(12, 80), Size = UDim2.new(1, -24, 0, TAB_STEP * 3), BackgroundTransparency = 1, Parent = Rail })
local Indicator = new("Frame", { Size = UDim2.new(1, 0, 0, 38), BackgroundColor3 = Theme.Panel, BorderSizePixel = 0, Parent = TabList }, { corner(9), stroke(Theme.Line, 1) })
local IndicatorBar = new("Frame", { Size = UDim2.fromOffset(3, 16), AnchorPoint = Vector2.new(0, 0.5), Position = UDim2.new(0, 0, 0.5, 0), BackgroundColor3 = accent(), BorderSizePixel = 0, Parent = Indicator }, { corner(2) })
table.insert(Refreshers, function(instant)
	if instant then
		IndicatorBar.BackgroundColor3 = accent()
	else
		tween(IndicatorBar, 0.3, { BackgroundColor3 = accent() })
	end
end)

local StatusBox = new("Frame", {
	AnchorPoint = Vector2.new(0, 1),
	Position = UDim2.new(0, 12, 1, -12),
	Size = UDim2.new(1, -24, 0, 96),
	BackgroundColor3 = Theme.Panel,
	BorderSizePixel = 0,
	Parent = Rail,
}, { corner(10), stroke(Theme.Line, 1), pad(10, 12, 10, 12), new("UIListLayout", { Padding = UDim.new(0, 4), SortOrder = Enum.SortOrder.LayoutOrder }) })

local Status = {}
for i, key in ipairs({ "MODE", "TARGETS", "LOCK", "HOOK" }) do
	local row = new("Frame", { Size = UDim2.new(1, 0, 0, 16), BackgroundTransparency = 1, LayoutOrder = i, Parent = StatusBox })
	label({ Parent = row, Size = UDim2.new(0, 60, 1, 0), Text = key, FontFace = Fonts.Mono, TextSize = 10, TextColor3 = Theme.Faint })
	Status[key] = label({
		Parent = row,
		Position = UDim2.fromOffset(60, 0),
		Size = UDim2.new(1, -60, 1, 0),
		Text = "—",
		FontFace = Fonts.Mono,
		TextSize = 11,
		TextXAlignment = Enum.TextXAlignment.Right,
		TextTruncate = Enum.TextTruncate.AtEnd,
	})
end

-- Content
local Content = new("Frame", { Position = UDim2.fromOffset(RAIL_W, 0), Size = UDim2.new(1, -RAIL_W, 1, 0), BackgroundTransparency = 1, Parent = Window })
local Header = new("Frame", { Size = UDim2.new(1, 0, 0, 72), BackgroundTransparency = 1, Parent = Content })
local PageTitle = label({ Parent = Header, Position = UDim2.fromOffset(24, 20), Size = UDim2.new(1, -150, 0, 24), FontFace = Fonts.Bold, TextSize = 20, Text = "" })
local PageDesc = label({ Parent = Header, Position = UDim2.fromOffset(24, 44), Size = UDim2.new(1, -150, 0, 16), FontFace = Fonts.Regular, TextSize = 12, TextColor3 = Theme.Sub, Text = "" })
new("Frame", { Position = UDim2.fromOffset(24, 72), Size = UDim2.new(1, -48, 0, 1), BackgroundColor3 = Theme.Line, BorderSizePixel = 0, Parent = Content })

local HideBtn = new("TextButton", {
	AnchorPoint = Vector2.new(1, 0),
	Position = UDim2.new(1, -20, 0, 22),
	Size = UDim2.fromOffset(0, 28),
	AutomaticSize = Enum.AutomaticSize.X,
	BackgroundColor3 = Theme.Panel,
	AutoButtonColor = false,
	Text = "",
	Parent = Header,
}, {
	corner(8),
	stroke(Theme.Line, 1),
	pad(0, 6, 0, 12),
	new("UIListLayout", { FillDirection = Enum.FillDirection.Horizontal, VerticalAlignment = Enum.VerticalAlignment.Center, Padding = UDim.new(0, 8), SortOrder = Enum.SortOrder.LayoutOrder }),
})
local HideText = label({ Parent = HideBtn, Size = UDim2.fromOffset(0, 28), AutomaticSize = Enum.AutomaticSize.X, Text = "Hide", TextSize = 12, TextColor3 = Theme.Sub, LayoutOrder = 1 })
local HideKey = new("Frame", { Size = UDim2.fromOffset(0, 18), AutomaticSize = Enum.AutomaticSize.X, BackgroundColor3 = Theme.Bg, BorderSizePixel = 0, LayoutOrder = 2, Parent = HideBtn }, { corner(5), pad(0, 6, 0, 6) })
local HideKeyLbl = label({ Parent = HideKey, Size = UDim2.fromOffset(0, 18), AutomaticSize = Enum.AutomaticSize.X, Text = "", FontFace = Fonts.Mono, TextSize = 10, TextColor3 = Theme.Faint })
bind(HideBtn.MouseEnter, function()
	tween(HideBtn, 0.15, { BackgroundColor3 = Theme.PanelHover })
	tween(HideText, 0.15, { TextColor3 = Theme.Text })
end)
bind(HideBtn.MouseLeave, function()
	tween(HideBtn, 0.2, { BackgroundColor3 = Theme.Panel })
	tween(HideText, 0.2, { TextColor3 = Theme.Sub })
end)

local PageHost = new("Frame", { Position = UDim2.fromOffset(0, 73), Size = UDim2.new(1, 0, 1, -73), BackgroundTransparency = 1, ClipsDescendants = true, Parent = Content })

local function newPage()
	local group = new("CanvasGroup", { Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1, BorderSizePixel = 0, Visible = false, Parent = PageHost })
	local scroll = new("ScrollingFrame", {
		Size = UDim2.fromScale(1, 1),
		BackgroundTransparency = 1,
		BorderSizePixel = 0,
		ScrollBarThickness = 2,
		ScrollBarImageColor3 = Theme.Off,
		CanvasSize = UDim2.new(),
		AutomaticCanvasSize = Enum.AutomaticSize.Y,
		ScrollingDirection = Enum.ScrollingDirection.Y,
		Parent = group,
	}, { pad(16, 20, 20, 20), new("UIListLayout", { Padding = UDim.new(0, 18), SortOrder = Enum.SortOrder.LayoutOrder }) })
	return { Group = group, Scroll = scroll, Order = 0 }
end

local function newSection(page, title)
	page.Order += 1
	local wrap = new("Frame", { Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y, BackgroundTransparency = 1, LayoutOrder = page.Order, Parent = page.Scroll }, {
		new("UIListLayout", { Padding = UDim.new(0, 8), SortOrder = Enum.SortOrder.LayoutOrder }),
	})
	label({ Parent = wrap, Size = UDim2.new(1, 0, 0, 14), Text = string.upper(title), FontFace = Fonts.Bold, TextSize = 10, TextColor3 = Theme.Faint, LayoutOrder = 0 })
	local box = new("Frame", { Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y, BackgroundColor3 = Theme.Panel, BorderSizePixel = 0, LayoutOrder = 1, Parent = wrap }, {
		corner(10),
		stroke(Theme.Line, 1),
		new("UIListLayout", { SortOrder = Enum.SortOrder.LayoutOrder }),
	})
	return { Box = box, Count = 0 }
end

local function newRow(section, height)
	section.Count += 1
	local row = new("TextButton", { Size = UDim2.new(1, 0, 0, height), BackgroundTransparency = 1, AutoButtonColor = false, Text = "", LayoutOrder = section.Count, Parent = section.Box })
	local hover = new("Frame", { Position = UDim2.fromOffset(4, 3), Size = UDim2.new(1, -8, 1, -6), BackgroundColor3 = Theme.PanelHover, BackgroundTransparency = 1, BorderSizePixel = 0, ZIndex = 0, Parent = row }, { corner(7) })
	if section.Count > 1 then
		new("Frame", { Position = UDim2.fromOffset(14, 0), Size = UDim2.new(1, -28, 0, 1), BackgroundColor3 = Theme.Line, BorderSizePixel = 0, Parent = row })
	end
	bind(row.MouseEnter, function()
		tween(hover, 0.18, { BackgroundTransparency = 0 })
	end)
	bind(row.MouseLeave, function()
		tween(hover, 0.25, { BackgroundTransparency = 1 })
	end)
	return row
end

local function rowLabel(row, title, desc, color)
	if desc then
		label({ Parent = row, Position = UDim2.fromOffset(16, 9), Size = UDim2.new(1, -170, 0, 16), Text = title, TextColor3 = color or Theme.Text })
		label({ Parent = row, Position = UDim2.fromOffset(16, 26), Size = UDim2.new(1, -170, 0, 14), Text = desc, FontFace = Fonts.Regular, TextSize = 11, TextColor3 = Theme.Faint, TextTruncate = Enum.TextTruncate.AtEnd })
	else
		label({ Parent = row, Position = UDim2.fromOffset(16, 0), Size = UDim2.new(1, -170, 1, 0), Text = title, TextColor3 = color or Theme.Text })
	end
end

local function addToggle(section, title, tbl, key, desc)
	local row = newRow(section, desc and 50 or 40)
	rowLabel(row, title, desc)
	local track = new("Frame", { AnchorPoint = Vector2.new(1, 0.5), Position = UDim2.new(1, -16, 0.5, 0), Size = UDim2.fromOffset(36, 20), BackgroundColor3 = Theme.Off, BorderSizePixel = 0, Parent = row }, { corner(10) })
	local trackScale = new("UIScale", { Parent = track })
	local knob = new("Frame", { AnchorPoint = Vector2.new(0, 0.5), Position = UDim2.new(0, 3, 0.5, 0), Size = UDim2.fromOffset(14, 14), BackgroundColor3 = Theme.Sub, BorderSizePixel = 0, Parent = track }, { corner(7) })
	local function render(instant)
		local on = tbl[key] == true
		local gt = { BackgroundColor3 = on and accent() or Theme.Off }
		local gk = { Position = on and UDim2.new(1, -17, 0.5, 0) or UDim2.new(0, 3, 0.5, 0), BackgroundColor3 = on and WHITE or Theme.Sub }
		if instant then
			track.BackgroundColor3 = gt.BackgroundColor3
			knob.Position, knob.BackgroundColor3 = gk.Position, gk.BackgroundColor3
		else
			tween(track, 0.22, gt)
			tween(knob, 0.32, gk, Enum.EasingStyle.Back)
		end
	end
	bind(row.MouseButton1Down, function()
		tween(trackScale, 0.1, { Scale = 0.92 })
	end)
	bind(row.MouseButton1Up, function()
		tween(trackScale, 0.25, { Scale = 1 }, Enum.EasingStyle.Back)
	end)
	bind(row.MouseLeave, function()
		tween(trackScale, 0.25, { Scale = 1 })
	end)
	bind(row.Activated, function()
		tbl[key] = not tbl[key]
		render(false)
		markDirty()
	end)
	table.insert(Refreshers, render)
	render(true)
end

local function addSlider(section, title, min, max, step, tbl, key, suffix)
	local row = newRow(section, 58)
	label({ Parent = row, Position = UDim2.fromOffset(16, 10), Size = UDim2.new(1, -120, 0, 16), Text = title })
	local valueBox = new("Frame", { AnchorPoint = Vector2.new(1, 0), Position = UDim2.new(1, -16, 0, 8), Size = UDim2.fromOffset(70, 20), BackgroundColor3 = Theme.Bg, BorderSizePixel = 0, Parent = row }, { corner(6), stroke(Theme.Line, 1) })
	local valueLbl = label({ Parent = valueBox, Size = UDim2.fromScale(1, 1), TextXAlignment = Enum.TextXAlignment.Center, FontFace = Fonts.Mono, TextSize = 11 })
	local track = new("Frame", { Position = UDim2.new(0, 16, 0, 40), Size = UDim2.new(1, -32, 0, 4), BackgroundColor3 = Theme.Off, BorderSizePixel = 0, Parent = row }, { corner(2) })
	local fill = new("Frame", { Size = UDim2.fromScale(0, 1), BackgroundColor3 = accent(), BorderSizePixel = 0, Parent = track }, { corner(2) })
	local knob = new("Frame", { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0, 0.5), Size = UDim2.fromOffset(12, 12), BackgroundColor3 = WHITE, BorderSizePixel = 0, ZIndex = 3, Parent = track }, { corner(6) })
	local knobStroke = stroke(accent(), 2)
	knobStroke.Parent = knob
	local hit = new("TextButton", { Position = UDim2.new(0, 10, 0, 28), Size = UDim2.new(1, -20, 0, 26), BackgroundTransparency = 1, Text = "", AutoButtonColor = false, ZIndex = 4, Parent = row })

	local function render(instant)
		local ratio = clamp((tbl[key] - min) / (max - min), 0, 1)
		valueLbl.Text = tostring(tbl[key]) .. (suffix or "")
		local a = accent()
		if instant then
			fill.Size = UDim2.fromScale(ratio, 1)
			knob.Position = UDim2.fromScale(ratio, 0.5)
			fill.BackgroundColor3 = a
			knobStroke.Color = a
		else
			tween(fill, 0.18, { Size = UDim2.fromScale(ratio, 1), BackgroundColor3 = a })
			tween(knob, 0.18, { Position = UDim2.fromScale(ratio, 0.5) })
			tween(knobStroke, 0.18, { Color = a })
		end
	end

	local dragging = false
	local function setFromX(x)
		local ratio = clamp((x - track.AbsolutePosition.X) / math.max(track.AbsoluteSize.X, 1), 0, 1)
		local v = min + math.floor(ratio * (max - min) / step + 0.5) * step
		tbl[key] = clamp(v, min, max)
		render(true)
	end
	bind(hit.InputBegan, function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 then
			dragging = true
			tween(knob, 0.15, { Size = UDim2.fromOffset(15, 15) })
			setFromX(input.Position.X)
		end
	end)
	bind(UIS.InputChanged, function(input)
		if dragging and input.UserInputType == Enum.UserInputType.MouseMovement then
			setFromX(input.Position.X)
		end
	end)
	bind(UIS.InputEnded, function(input)
		if dragging and input.UserInputType == Enum.UserInputType.MouseButton1 then
			dragging = false
			tween(knob, 0.2, { Size = UDim2.fromOffset(12, 12) }, Enum.EasingStyle.Back)
			markDirty()
		end
	end)
	table.insert(Refreshers, render)
	render(true)
end

local function addSegment(section, title, options, tbl, key, desc)
	local row = newRow(section, desc and 50 or 40)
	rowLabel(row, title, desc)
	local W = 64
	local holder = new("Frame", { AnchorPoint = Vector2.new(1, 0.5), Position = UDim2.new(1, -16, 0.5, 0), Size = UDim2.fromOffset(W * #options + 4, 26), BackgroundColor3 = Theme.Bg, BorderSizePixel = 0, Parent = row }, { corner(8), stroke(Theme.Line, 1) })
	local pill = new("Frame", { Position = UDim2.fromOffset(2, 2), Size = UDim2.fromOffset(W, 22), BackgroundColor3 = accent(), BorderSizePixel = 0, Parent = holder }, { corner(6) })
	local buttons = {}
	local function render(instant)
		local i = tbl[key]
		local goal = { Position = UDim2.fromOffset(2 + (i - 1) * W, 2), BackgroundColor3 = accent() }
		if instant then
			pill.Position, pill.BackgroundColor3 = goal.Position, goal.BackgroundColor3
		else
			tween(pill, 0.3, goal)
		end
		for j, b in ipairs(buttons) do
			tween(b, instant and 0 or 0.2, { TextColor3 = (j == i) and Theme.Bg or Theme.Sub })
		end
	end
	for i, opt in ipairs(options) do
		local b = new("TextButton", { Position = UDim2.fromOffset(2 + (i - 1) * W, 2), Size = UDim2.fromOffset(W, 22), BackgroundTransparency = 1, Text = opt, FontFace = Fonts.Bold, TextSize = 11, TextColor3 = Theme.Sub, AutoButtonColor = false, ZIndex = 2, Parent = holder })
		buttons[i] = b
		bind(b.Activated, function()
			tbl[key] = i
			render(false)
			markDirty()
		end)
	end
	table.insert(Refreshers, render)
	render(true)
end

local function addSwatches(section, title, tbl, key, desc)
	local row = newRow(section, desc and 50 or 44)
	rowLabel(row, title, desc)
	local holder = new("Frame", { AnchorPoint = Vector2.new(1, 0.5), Position = UDim2.new(1, -12, 0.5, 0), Size = UDim2.fromOffset(#Palette * 24, 24), BackgroundTransparency = 1, Parent = row })
	local swatches = {}
	local function render(instant)
		for i, sw in ipairs(swatches) do
			local on = tbl[key] == i
			tween(sw.Ring, instant and 0 or 0.2, { Transparency = on and 0 or 1 })
			tween(sw.Button, instant and 0 or 0.25, { Size = on and UDim2.fromOffset(18, 18) or UDim2.fromOffset(14, 14) }, Enum.EasingStyle.Back)
		end
	end
	for i, p in ipairs(Palette) do
		local b = new("TextButton", { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset((i - 1) * 24 + 12, 12), Size = UDim2.fromOffset(14, 14), BackgroundColor3 = p.Color, Text = "", AutoButtonColor = false, Parent = holder }, { corner(9) })
		local ring = stroke(WHITE, 2, 1)
		ring.Parent = b
		swatches[i] = { Button = b, Ring = ring }
		bind(b.MouseEnter, function()
			if tbl[key] ~= i then
				tween(b, 0.15, { Size = UDim2.fromOffset(17, 17) })
			end
		end)
		bind(b.MouseLeave, function()
			if tbl[key] ~= i then
				tween(b, 0.2, { Size = UDim2.fromOffset(14, 14) })
			end
		end)
		bind(b.Activated, function()
			tbl[key] = i
			markDirty()
			refreshAll()
		end)
	end
	table.insert(Refreshers, render)
	render(true)
end

local Capture = nil
local KeyLabels = {}
local function refreshKeyLabels()
	for _, l in ipairs(KeyLabels) do
		l.Text = keyLabel(Config.Menu.Key)
	end
end
table.insert(KeyLabels, HideKeyLbl)

local function addKeybind(section, title, tbl, key, desc)
	local row = newRow(section, desc and 50 or 40)
	rowLabel(row, title, desc)
	local capStroke = stroke(Theme.Line, 1)
	local cap = new("TextButton", {
		AnchorPoint = Vector2.new(1, 0.5),
		Position = UDim2.new(1, -16, 0.5, 0),
		Size = UDim2.fromOffset(0, 24),
		AutomaticSize = Enum.AutomaticSize.X,
		BackgroundColor3 = Theme.Bg,
		Text = "",
		FontFace = Fonts.Mono,
		TextSize = 11,
		TextColor3 = Theme.Text,
		AutoButtonColor = false,
		Parent = row,
	}, { corner(6), capStroke, pad(0, 10, 0, 10) })
	local function render()
		cap.Text = keyLabel(tbl[key])
		cap.TextColor3 = Theme.Text
		tween(capStroke, 0.2, { Color = Theme.Line })
	end
	bind(cap.Activated, function()
		cap.Text = "press a key…"
		cap.TextColor3 = accent()
		tween(capStroke, 0.2, { Color = accent() })
		Capture = function(kc)
			if kc ~= Enum.KeyCode.Escape and kc ~= Enum.KeyCode.Unknown then
				tbl[key] = kc.Name
				markDirty()
			end
			render()
			refreshKeyLabels()
		end
	end)
	render()
end

local function addDanger(section, title, desc, actionText, fn)
	local row = newRow(section, 50)
	rowLabel(row, title, desc)
	local btn = new("TextButton", {
		AnchorPoint = Vector2.new(1, 0.5),
		Position = UDim2.new(1, -16, 0.5, 0),
		Size = UDim2.fromOffset(86, 28),
		BackgroundColor3 = Theme.Danger,
		BackgroundTransparency = 0.86,
		Text = actionText,
		FontFace = Fonts.Bold,
		TextSize = 12,
		TextColor3 = Theme.Danger,
		AutoButtonColor = false,
		Parent = row,
	}, { corner(8) })
	local armed = false
	bind(btn.MouseEnter, function()
		if not armed then
			tween(btn, 0.15, { BackgroundTransparency = 0.74 })
		end
	end)
	bind(btn.MouseLeave, function()
		if not armed then
			tween(btn, 0.2, { BackgroundTransparency = 0.86 })
		end
	end)
	bind(btn.Activated, function()
		if armed then
			fn()
			return
		end
		armed = true
		btn.Text = "Confirm"
		tween(btn, 0.2, { BackgroundTransparency = 0, TextColor3 = WHITE })
		task.delay(2.5, function()
			if armed and btn.Parent then
				armed = false
				btn.Text = actionText
				tween(btn, 0.25, { BackgroundTransparency = 0.86, TextColor3 = Theme.Danger })
			end
		end)
	end)
end

-- Toasts
local ToastHost = new("Frame", {
	AnchorPoint = Vector2.new(1, 1),
	Position = UDim2.new(1, -20, 1, -20),
	Size = UDim2.fromOffset(300, 300),
	BackgroundTransparency = 1,
	Parent = Gui,
}, { new("UIListLayout", { VerticalAlignment = Enum.VerticalAlignment.Bottom, HorizontalAlignment = Enum.HorizontalAlignment.Right, Padding = UDim.new(0, 8), SortOrder = Enum.SortOrder.LayoutOrder }) })

local toastOrder = 0
local function toast(title, body, color)
	toastOrder += 1
	local card = new("CanvasGroup", {
		Size = UDim2.fromOffset(290, 0),
		AutomaticSize = Enum.AutomaticSize.Y,
		BackgroundColor3 = Theme.Bg,
		BorderSizePixel = 0,
		GroupTransparency = 1,
		LayoutOrder = toastOrder,
		Parent = ToastHost,
	}, { corner(10), stroke(Theme.Stroke, 1), pad(10, 14, 11, 16), new("UIListLayout", { Padding = UDim.new(0, 3), SortOrder = Enum.SortOrder.LayoutOrder }) })
	new("Frame", { Size = UDim2.new(0, 3, 1, 0), Position = UDim2.fromOffset(-16, 0), BackgroundColor3 = color or accent(), BorderSizePixel = 0, Parent = card })
	label({ Parent = card, Size = UDim2.new(1, 0, 0, 16), Text = title, FontFace = Fonts.Bold, TextSize = 12, TextColor3 = color or accent(), LayoutOrder = 1 })
	label({ Parent = card, Size = UDim2.new(1, 0, 0, 0), AutomaticSize = Enum.AutomaticSize.Y, Text = body, FontFace = Fonts.Regular, TextSize = 12, TextColor3 = Theme.Sub, TextWrapped = true, LayoutOrder = 2 })
	tween(card, 0.3, { GroupTransparency = 0 })
	task.delay(3.5, function()
		if card.Parent then
			tween(card, 0.35, { GroupTransparency = 1 }).Completed:Wait()
			card:Destroy()
		end
	end)
end

-- Reopen pill
local Pill = new("CanvasGroup", {
	AnchorPoint = Vector2.new(0.5, 0),
	Position = UDim2.new(0.5, 0, 0, 14),
	Size = UDim2.fromOffset(0, 34),
	AutomaticSize = Enum.AutomaticSize.X,
	BackgroundColor3 = Theme.Bg,
	BorderSizePixel = 0,
	GroupTransparency = 1,
	Visible = false,
	Active = true,
	Parent = Gui,
}, {
	corner(17),
	stroke(Theme.Stroke, 1),
	pad(0, 8, 0, 14),
	new("UIListLayout", { FillDirection = Enum.FillDirection.Horizontal, VerticalAlignment = Enum.VerticalAlignment.Center, Padding = UDim.new(0, 9), SortOrder = Enum.SortOrder.LayoutOrder }),
})
local PillScale = new("UIScale", { Scale = 0.9, Parent = Pill })
local PillDot = new("Frame", { Size = UDim2.fromOffset(8, 8), BackgroundColor3 = accent(), BorderSizePixel = 0, LayoutOrder = 1, Parent = Pill }, { corner(4) })
label({ Parent = Pill, Size = UDim2.fromOffset(0, 34), AutomaticSize = Enum.AutomaticSize.X, Text = "ShooterSuite", FontFace = Fonts.Bold, TextSize = 12, LayoutOrder = 2 })
local PillKey = new("Frame", { Size = UDim2.fromOffset(0, 20), AutomaticSize = Enum.AutomaticSize.X, BackgroundColor3 = Theme.Panel, BorderSizePixel = 0, LayoutOrder = 3, Parent = Pill }, { corner(6), pad(0, 7, 0, 7) })
table.insert(KeyLabels, label({ Parent = PillKey, Size = UDim2.fromOffset(0, 20), AutomaticSize = Enum.AutomaticSize.X, Text = "", FontFace = Fonts.Mono, TextSize = 10, TextColor3 = Theme.Sub }))
TweenService:Create(PillDot, TweenInfo.new(0.9, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), { BackgroundTransparency = 0.65 }):Play()
table.insert(Refreshers, function()
	PillDot.BackgroundColor3 = accent()
end)

local function makeDraggable(handle, target, onClick)
	local dragging, start, startPos, moved = false, nil, nil, false
	bind(handle.InputBegan, function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging, moved = true, false
			start, startPos = input.Position, target.Position
		end
	end)
	bind(UIS.InputChanged, function(input)
		if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
			local d = input.Position - start
			if d.Magnitude > 3 then
				moved = true
			end
			if moved then
				target.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + d.X, startPos.Y.Scale, startPos.Y.Offset + d.Y)
			end
		end
	end)
	bind(UIS.InputEnded, function(input)
		if dragging and (input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch) then
			dragging = false
			if not moved and onClick then
				onClick()
			end
		end
	end)
end

-- Menu visibility
local MenuOpen = false
local SavedMouseIcon = nil
local HintShown = false

local function showPill(show)
	if show then
		Pill.Visible = true
		tween(Pill, 0.3, { GroupTransparency = 0 })
		tween(PillScale, 0.4, { Scale = 1 }, Enum.EasingStyle.Back)
	else
		tween(Pill, 0.18, { GroupTransparency = 1 })
		tween(PillScale, 0.18, { Scale = 0.9 }).Completed:Once(function()
			if MenuOpen or not Config.Menu.Pill then
				Pill.Visible = false
			end
		end)
	end
end

local function setMenu(open)
	if Unloaded or MenuOpen == open then
		return
	end
	MenuOpen = open
	if open then
		SavedMouseIcon = UIS.MouseIconEnabled
		Holder.Visible = true
		Window.GroupTransparency = 1
		HolderScale.Scale = 0.95
		tween(Window, 0.28, { GroupTransparency = 0 })
		tween(HolderScale, 0.45, { Scale = 1 }, Enum.EasingStyle.Back)
		for _, s in ipairs(ShadowLayers) do
			s.Frame.BackgroundTransparency = 1
			tween(s.Frame, 0.4, { BackgroundTransparency = s.Base })
		end
		showPill(false)
	else
		tween(Window, 0.2, { GroupTransparency = 1 })
		tween(HolderScale, 0.2, { Scale = 0.96 }, Enum.EasingStyle.Quad)
		for _, s in ipairs(ShadowLayers) do
			tween(s.Frame, 0.2, { BackgroundTransparency = 1 })
		end
		task.delay(0.21, function()
			if not MenuOpen and not Unloaded then
				Holder.Visible = false
			end
		end)
		if SavedMouseIcon ~= nil then
			UIS.MouseIconEnabled = SavedMouseIcon
		end
		if Config.Menu.Pill then
			showPill(true)
		end
		if not HintShown then
			HintShown = true
			toast("Menu hidden", ("Press %s%s to bring it back."):format(keyLabel(Config.Menu.Key), Config.Menu.Pill and " or click the pill up top" or ""))
		end
	end
end

RunService:BindToRenderStep(RENDER_NAME, Enum.RenderPriority.Last.Value + 1, function()
	if MenuOpen and not Unloaded then
		UIS.MouseBehavior = Enum.MouseBehavior.Default
		UIS.MouseIconEnabled = true
	end
end)

bind(HideBtn.Activated, function()
	setMenu(false)
end)
makeDraggable(Header, Holder)
makeDraggable(Brand, Holder)
makeDraggable(Pill, Pill, function()
	setMenu(true)
end)

bind(UIS.InputBegan, function(input)
	if Capture then
		if input.UserInputType == Enum.UserInputType.Keyboard then
			local cb = Capture
			Capture = nil
			cb(input.KeyCode)
		end
		return
	end
	if UIS:GetFocusedTextBox() then
		return
	end
	if input.KeyCode == menuKey() then
		setMenu(not MenuOpen)
	end
end)

-- Tabs
local Tabs = {}
local ActiveTab = nil

local function selectTab(i, instant)
	if ActiveTab == i then
		return
	end
	ActiveTab = i
	tween(Indicator, instant and 0 or 0.35, { Position = UDim2.fromOffset(0, (i - 1) * TAB_STEP) })
	for j, tb in ipairs(Tabs) do
		local on = j == i
		tween(tb.Name, 0.2, { TextColor3 = on and Theme.Text or Theme.Sub })
		tween(tb.Index, 0.2, { TextColor3 = on and accent() or Theme.Faint })
		local pg = tb.Page.Group
		if on then
			pg.Visible = true
			pg.GroupTransparency = 1
			pg.Position = UDim2.fromOffset(0, 10)
			tween(pg, 0.32, { GroupTransparency = 0, Position = UDim2.fromOffset(0, 0) })
		else
			pg.Visible = false
		end
	end
	local tab = Tabs[i]
	PageTitle.Text = tab.Title
	PageDesc.Text = tab.Desc
	PageTitle.TextTransparency, PageDesc.TextTransparency = 1, 1
	PageTitle.Position = UDim2.fromOffset(24, 25)
	tween(PageTitle, 0.3, { TextTransparency = 0, Position = UDim2.fromOffset(24, 20) })
	tween(PageDesc, 0.4, { TextTransparency = 0 })
end

local function addTab(title, desc)
	local i = #Tabs + 1
	local btn = new("TextButton", { Position = UDim2.fromOffset(0, (i - 1) * TAB_STEP), Size = UDim2.new(1, 0, 0, 38), BackgroundTransparency = 1, Text = "", AutoButtonColor = false, ZIndex = 2, Parent = TabList })
	local idx = label({ Parent = btn, Position = UDim2.fromOffset(16, 0), Size = UDim2.new(0, 22, 1, 0), Text = string.format("%02d", i), FontFace = Fonts.Mono, TextSize = 10, TextColor3 = Theme.Faint, ZIndex = 2 })
	local name = label({ Parent = btn, Position = UDim2.fromOffset(42, 0), Size = UDim2.new(1, -50, 1, 0), Text = title, TextSize = 13, TextColor3 = Theme.Sub, ZIndex = 2 })
	local page = newPage()
	Tabs[i] = { Button = btn, Index = idx, Name = name, Page = page, Title = title, Desc = desc }
	bind(btn.Activated, function()
		selectTab(i)
	end)
	bind(btn.MouseEnter, function()
		if ActiveTab ~= i then
			tween(name, 0.15, { TextColor3 = Theme.Text })
		end
	end)
	bind(btn.MouseLeave, function()
		if ActiveTab ~= i then
			tween(name, 0.2, { TextColor3 = Theme.Sub })
		end
	end)
	return page
end
table.insert(Refreshers, function()
	if ActiveTab and Tabs[ActiveTab] then
		tween(Tabs[ActiveTab].Index, 0.2, { TextColor3 = accent() })
	end
end)

-- Pages
local visuals = addTab("Visuals", "Boxes, bones and chams on every entity in your room.")
local s = newSection(visuals, "Players")
addToggle(s, "ESP", Config.ESP, "Enabled", "Master switch for everything on this page")
addToggle(s, "Box", Config.ESP, "Box")
addToggle(s, "Skeleton", Config.ESP, "Skeleton")
addToggle(s, "Health bar", Config.ESP, "Healthbar")
addToggle(s, "Name", Config.ESP, "Name")
addToggle(s, "Distance & HP", Config.ESP, "Distance")
addToggle(s, "Tracers", Config.ESP, "Tracer")
addToggle(s, "Chams", Config.ESP, "Chams", "Highlight through walls, engine caps it at 31")
s = newSection(visuals, "Filtering")
addToggle(s, "Team check", Config, "TeamCheck", "Game's own friendly check; FFA counts everyone")
addToggle(s, "Show teammates", Config.ESP, "ShowTeam", "Draw friendlies in team color")
addToggle(s, "Same match only", Config, "SameMatch", "Skip lobby players and other rooms")
addToggle(s, "Visibility tint", Config.ESP, "VisTint", "Dim anyone behind cover")
addSlider(s, "Max distance", 100, 3000, 50, Config.ESP, "MaxDistance", " st")
s = newSection(visuals, "Colors")
addSwatches(s, "Enemy", Config.ESP, "EnemyColor")
addSwatches(s, "Team", Config.ESP, "TeamColor")

local combat = addTab("Combat", "Silent aim through the game's own targeting call.")
s = newSection(combat, "Silent aim")
addToggle(s, "Silent aim", Config.Aim, "SilentAim", "Redirects CameraController targeting to the lock")
addToggle(s, "Fire check", Config.Aim, "FireCheck", "Only redirect while LMB is held")
addToggle(s, "Visible only", Config.Aim, "VisibleOnly", "Off locks through walls; server decides if it lands")
addSegment(s, "Aim part", { "Head", "Torso" }, Config.Aim, "Part", "Head hits flag TargetHeadshot")
addSlider(s, "FOV radius", 30, 500, 5, Config.Aim, "FOVRadius", " px")
addSlider(s, "Max distance", 100, 3000, 50, Config.Aim, "MaxDistance", " st")
s = newSection(combat, "FOV wheel")
addToggle(s, "Show wheel", Config.Aim, "ShowFOV")
addToggle(s, "Fill", Config.Aim, "FillFOV")
addToggle(s, "Rotating ticks", Config.Aim, "Ticks")
addToggle(s, "Target line", Config.Aim, "Line")
addToggle(s, "Target marker", Config.Aim, "Marker")

local settings = addTab("Settings", "Keybinds, accent and session control.")
s = newSection(settings, "Menu")
addKeybind(s, "Menu key", Config.Menu, "Key", "Toggles this window; Esc cancels rebinding")
addSwatches(s, "Accent", Config.Menu, "Accent")
addToggle(s, "Reopen pill", Config.Menu, "Pill", "Draggable button up top while the menu is hidden")
s = newSection(settings, "Session")
addDanger(s, "Unload", "Removes drawings and UI, hooks go inert", "Unload", function()
	unload()
end)

refreshKeyLabels()
for _, fn in ipairs(Refreshers) do
	pcall(fn, true)
end
selectTab(1, true)

--// ───────────── Main loop ─────────────

local lastScan = 0
local startClock = os.clock()

local function updateStatus()
	Status.MODE.Text = ModeName or "Lobby"
	local n = 0
	for _, t in pairs(Targets) do
		if t.Targetable then
			n += 1
		end
	end
	Status.TARGETS.Text = tostring(n)
	Status.LOCK.Text = LockedTarget and LockedTarget.Name or "—"
	Status.LOCK.TextColor3 = LockedTarget and accent() or Theme.Text
	Status.HOOK.Text = Shared.HookOk and "live" or "offline"
	Status.HOOK.TextColor3 = Shared.HookOk and Color3.fromRGB(110, 230, 150) or Theme.Danger
end

bind(RunService.RenderStepped, function()
	if Unloaded then
		return
	end
	local now = os.clock()
	if now - lastScan >= 0.3 then
		lastScan = now
		refreshTargets()
		updateStatus()
		if Dirty then
			saveConfig()
		end
	end

	local cam = Workspace.CurrentCamera
	if not cam then
		return
	end
	local camPos = cam.CFrame.Position
	local mouse = UIS:GetMouseLocation()

	for _, t in pairs(Targets) do
		local c = t.Cache
		local ok = c ~= nil and c.Head.Parent ~= nil and c.Root.Parent ~= nil and t.InWorld
		local alive = false
		if ok then
			local hp, maxhp
			hp, maxhp, alive = readStats(t)
			t.HP, t.MaxHP = hp, maxhp
			t.Distance = (c.Root.Position - camPos).Magnitude
		else
			t.Distance = math.huge
		end
		local live = ok and alive
		t.Targetable = live and not (Config.TeamCheck and t.Friendly)
		t.Drawable = live and (not t.Friendly or not Config.TeamCheck or Config.ESP.ShowTeam)
	end

	LockedTarget, LockedPart, LockedScreen = pickTarget(mouse, camPos)

	for _, t in pairs(Targets) do
		if Config.ESP.Enabled and t.Drawable and t.Distance <= Config.ESP.MaxDistance then
			drawESP(t, cam, camPos)
		else
			hideStore(t.Store)
		end
	end

	drawOverlay(now - startClock, mouse)
end)

unload = function()
	if Unloaded then
		return
	end
	Unloaded = true
	Shared.Redirect = nil
	pcall(RunService.UnbindFromRenderStep, RunService, RENDER_NAME)
	for _, c in ipairs(Connections) do
		pcall(c.Disconnect, c)
	end
	for key, t in pairs(Targets) do
		destroyStore(t.Store)
		Targets[key] = nil
	end
	for k, d in pairs(Overlay) do
		if k == "Ticks" then
			for _, tk in ipairs(d) do
				pcall(tk.Remove, tk)
			end
		else
			pcall(d.Remove, d)
		end
	end
	if MenuOpen and SavedMouseIcon ~= nil then
		UIS.MouseIconEnabled = SavedMouseIcon
	end
	if Dirty then
		saveConfig()
	end
	Gui:Destroy()
	HighlightFolder:Destroy()
	env.__SHOOTER_SUITE_UNLOAD = nil
end
env.__SHOOTER_SUITE_UNLOAD = unload

refreshTargets()
updateStatus()
setMenu(true)
toast(
	"ShooterSuite loaded",
	Shared.HookOk and ("Targeting hook live. %s toggles the menu."):format(keyLabel(Config.Menu.Key))
		or ("Silent aim offline: %s"):format(tostring(Shared.HookError)),
	Shared.HookOk and nil or Theme.Danger
)
